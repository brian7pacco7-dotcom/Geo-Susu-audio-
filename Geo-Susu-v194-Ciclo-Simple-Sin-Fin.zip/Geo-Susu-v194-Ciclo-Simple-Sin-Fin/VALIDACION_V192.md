# Geo Susu v192 - Procesamiento prioritario

## Correccion aplicada

- Una pregunta valida tiene prioridad sobre cualquier reconexion de Google interno.
- `onError`, el watchdog de sesion y el supervisor revisan primero el texto reconocido.
- Si existe una pregunta completa, se bloquea el ciclo en estado de procesamiento, se cancelan temporizadores y se responde una sola vez.
- Solo se reconecta Google cuando no existe texto util.
- Las preguntas locales de fecha y hora siguen resolviendose antes de JSON o NET.
- No se cambiaron sensibilidad, tiempos 4200/2600/2600, rutas JSON/NET/AUTO, APIs, TTS, interfaz ni permisos.

## Caso corregido

`que dia es hoy` ya no puede quedar visible mientras el servicio entra en `Reconectando Google interno`. Si Google falla durante la confirmacion, la pregunta se procesa primero.
