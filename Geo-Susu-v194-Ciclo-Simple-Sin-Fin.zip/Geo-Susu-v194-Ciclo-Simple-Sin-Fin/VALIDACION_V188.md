# Geo Susu v188 - Restauracion exacta del Google interno de v181

Esta version parte directamente del ZIP original `Geo-Susu-v181-Ciclo-Ruido-y-Pegar-API.zip`.

## Regla aplicada

- No se mezclo codigo de v182, v183, v184, v185, v186 ni v187.
- `GoogleInternalListenService.kt` es identico al de v181.
- `MainActivity.kt`, `SpeechTranscriptMerger.kt`, `VoiceQuestionNormalizer.kt`, JSON, NET, AUTO, TTS, Vosk y los botones PEGAR son los de v181.
- El unico cambio funcionalmente neutro es el numero de version para permitir instalarla sobre versiones posteriores:
  - `versionCode 188`
  - `versionName 18.8.0`

## Verificacion

- ZIP validado con `unzip -t`.
- Hash de `GoogleInternalListenService.kt` comparado con v181: identico.
- No contiene `SpeechDictionary.kt` ni watchdogs agregados en versiones posteriores.
