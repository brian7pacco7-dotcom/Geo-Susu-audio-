package com.bph.geosusuaudio

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ComponentCallbacks2
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

class GoogleInternalListenService : Service(), TextToSpeech.OnInitListener {

    private lateinit var jsonRepository: JsonKnowledgeRepository
    private lateinit var questionRouter: QuestionRouter
    private lateinit var memory: MemoryStore
    private lateinit var modeSettings: AnswerModeSettings
    private lateinit var appSettings: AppSettings
    private val onlineProvider by lazy { OnlineAnswerProvider(this) }

    private val handler = Handler(Looper.getMainLooper())
    private val backgroundLock = Any()
    private val routeExecutor: ExecutorService = Executors.newSingleThreadExecutor { task ->
        Thread(task, "GeoSusu-JSON").apply { isDaemon = true }
    }
    private val netExecutor: ExecutorService = Executors.newSingleThreadExecutor { task ->
        Thread(task, "GeoSusu-NET").apply { isDaemon = true }
    }
    @Volatile private var routeFuture: Future<*>? = null
    @Volatile private var netFuture: Future<*>? = null

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var wakeLock: PowerManager.WakeLock? = null

    @Volatile private var running = false
    @Volatile private var isSpeaking = false
    @Volatile private var isListening = false
    @Volatile private var isProcessing = false
    @Volatile private var onlineRequestVersion = 0
    private val questionDispatchInFlight = AtomicBoolean(false)

    private var lastHeard = ""
    private var lastHeardTime = 0L
    private var lastSpokenNormalized = ""
    private var lastPartial = ""
    private var currentSessionLastTextAt = 0L
    private var currentSessionSpeechStarted = false
    private var partialRunnable: Runnable? = null
    private var pendingNormalQuestion = ""
    private var pendingNormalQuestionRunnable: Runnable? = null
    private var pendingNormalQuestionSerial = 0L

    // Conserva únicamente una frase realmente incompleta entre dos sesiones.
    // No existe modo especial, comando de cierre ni estado de pregunta larga.
    private var continuationBuffer = ""

    // Cada sesion de Google tiene un identificador propio. Los callbacks tardios
    // de una sesion destruida se ignoran y no pueden bloquear la sesion nueva.
    private var sessionSerial = 0L
    private var activeSessionId = 0L
    private var pendingStartRunnable: Runnable? = null
    private var pendingStartSerial = 0L
    private var sessionWatchdogRunnable: Runnable? = null
    private var loopSupervisorRunnable: Runnable? = null
    private var lastRecognizerEventAt = 0L
    private var consecutiveRecognizerErrors = 0

    // Control independiente del lector de voz. Si Android no entrega onDone,
    // el servicio libera el estado y vuelve a escuchar por si solo.
    private var speechSerial = 0L
    private var activeUtteranceId: String? = null
    private var ttsWatchdogRunnable: Runnable? = null
    private var ttsStateMonitorRunnable: Runnable? = null
    private var speechStartedAt = 0L
    private var postSpeechGuardRunnable: Runnable? = null

    // Evita saturar el hilo principal con decenas de emisiones RMS por segundo.
    private var lastLevelDispatchAt = 0L
    private var lastLevelSent = -1

    // Compatibilidad de idioma para Google interno. Algunos dispositivos rechazan
    // es-PE con ERROR_LANGUAGE_NOT_SUPPORTED (12) o ERROR_LANGUAGE_UNAVAILABLE (13).
    // Se prueba una lista de variantes espanolas y se recuerda la que funciona.
    private val languagePreferences by lazy {
        getSharedPreferences(LANGUAGE_PREFS_NAME, MODE_PRIVATE)
    }
    private var recognitionLanguageCandidates: List<String> = emptyList()
    private var recognitionLanguageIndex = 0

    override fun onCreate() {
        super.onCreate()
        val appContext = applicationContext
        jsonRepository = JsonKnowledgeRepository(appContext)
        questionRouter = QuestionRouter(jsonRepository)
        memory = MemoryStore(appContext)
        modeSettings = AnswerModeSettings(appContext)
        appSettings = AppSettings(appContext)
        warmJsonInBackground()
        initializeRecognitionLanguages()
        tts = TextToSpeech(this, this)
        createChannel()
        acquireWakeLock()
        startLoopSupervisor()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification("Susurro Google activo"))
        renewWakeLockIfNeeded()

        val wasRunning = running
        running = true

        // Una nueva pulsacion en ESCUCHAR tambien sirve como recuperacion manual,
        // pero nunca debe interrumpir una pregunta que ya esta confirmandose.
        val awaitingConfirmation = pendingNormalQuestion.isNotBlank() &&
            pendingNormalQuestionRunnable != null
        if (!wasRunning || (!isSpeaking && !isListening && !isProcessing && !awaitingConfirmation)) {
            scheduleFreshSession(350L, "inicio del servicio")
        } else if (!isSpeaking && !isProcessing && !awaitingConfirmation && !questionDispatchInFlight.get()) {
            scheduleFreshSession(180L, "reinicio solicitado")
        }

        return START_STICKY
    }

    private fun scheduleFreshSession(delayMs: Long = 300L, reason: String = "reinicio") {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { scheduleFreshSession(delayMs, reason) }
            return
        }
        if (!running || isSpeaking || isProcessing || questionDispatchInFlight.get()) return

        cancelPendingStart()
        cancelSessionWatchdog()
        cancelPartialRunnable()

        isListening = false
        activeSessionId = 0L
        destroyRecognizerOnly()

        val requestId = ++pendingStartSerial
        val safeDelay = delayMs.coerceAtLeast(RECOGNIZER_SETTLE_DELAY_MS)
        val runnable = Runnable {
            if (requestId != pendingStartSerial) return@Runnable
            pendingStartRunnable = null
            if (!running || isSpeaking || isProcessing || isListening || questionDispatchInFlight.get()) {
                return@Runnable
            }
            startFreshRecognizerSession(reason)
        }
        pendingStartRunnable = runnable
        handler.postDelayed(runnable, safeDelay)
        logLoopState("session_scheduled", extra = "reason=$reason delayMs=$safeDelay request=$requestId")
    }

    private fun cancelPendingStart() {
        pendingStartSerial += 1L
        pendingStartRunnable?.let { handler.removeCallbacks(it) }
        pendingStartRunnable = null
    }

    private fun startFreshRecognizerSession(reason: String) {
        if (!running || isSpeaking || isProcessing || isListening || questionDispatchInFlight.get()) return

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            sendUpdate("Falta permiso de micrófono", "", "Activa permiso de micrófono.", 0)
            stopSelf()
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendUpdate("Google interno no disponible", "", "Reintentando automáticamente.", 0)
            scheduleFreshSession(5000L, "servicio de voz no disponible")
            return
        }

        val sessionId = ++sessionSerial
        activeSessionId = sessionId
        lastRecognizerEventAt = SystemClock.elapsedRealtime()
        lastPartial = ""
        currentSessionLastTextAt = 0L
        currentSessionSpeechStarted = false
        lastLevelSent = -1
        lastLevelDispatchAt = 0L

        try {
            prepareAudioRouteForUsbMic()
            val newRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            newRecognizer.setRecognitionListener(createRecognitionListener(sessionId))
            recognizer = newRecognizer

            isListening = true
            sendUpdate("Susurro Google: escuchando...", "", "", 0)
            newRecognizer.startListening(buildIntent())
            scheduleSessionWatchdog(sessionId)
            logLoopState("session_start", sessionId, "reason=$reason")
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo iniciar la sesion Google $sessionId", e)
            if (activeSessionId == sessionId) {
                activeSessionId = 0L
                isListening = false
            }
            destroyRecognizerOnly()
            sendUpdate("Reiniciando Google interno...", "", "", -1)
            scheduleFreshSession(1200L, "fallo al iniciar")
        }
    }

    private fun buildIntent(): Intent {
        val languageTag = currentRecognitionLanguage()
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageTag)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 4200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2600L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2600L)
            if (Build.VERSION.SDK_INT >= 33) {
                val hints = jsonRepository.recognitionHints(40)
                if (hints.isNotEmpty()) {
                    putStringArrayListExtra(RecognizerIntent.EXTRA_BIASING_STRINGS, hints)
                }
            }
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
    }

    private fun initializeRecognitionLanguages() {
        val saved = languagePreferences.getString(KEY_WORKING_LANGUAGE, null)
            ?.trim()
            ?.takeIf { it.isNotBlank() }
        val phoneLanguage = Locale.getDefault().toLanguageTag()
            .trim()
            .takeIf { Locale.getDefault().language.equals("es", ignoreCase = true) }

        recognitionLanguageCandidates = listOfNotNull(
            saved,
            "es-PE",
            "es-419",
            "es-ES",
            phoneLanguage,
            "es"
        ).distinctBy { it.lowercase(Locale.ROOT) }

        recognitionLanguageIndex = 0
        Log.d(TAG, "Idiomas Google interno: $recognitionLanguageCandidates")
    }

    private fun currentRecognitionLanguage(): String {
        if (recognitionLanguageCandidates.isEmpty()) initializeRecognitionLanguages()
        return recognitionLanguageCandidates
            .getOrElse(recognitionLanguageIndex) { "es" }
    }

    private fun advanceRecognitionLanguage(): String? {
        if (recognitionLanguageCandidates.isEmpty()) initializeRecognitionLanguages()
        val nextIndex = recognitionLanguageIndex + 1
        if (nextIndex >= recognitionLanguageCandidates.size) return null
        recognitionLanguageIndex = nextIndex
        return currentRecognitionLanguage()
    }

    private fun resetRecognitionLanguageCycle() {
        languagePreferences.edit().remove(KEY_WORKING_LANGUAGE).apply()
        recognitionLanguageIndex = 0
    }

    private fun rememberWorkingRecognitionLanguage() {
        val languageTag = currentRecognitionLanguage()
        val saved = languagePreferences.getString(KEY_WORKING_LANGUAGE, null)
        if (!saved.equals(languageTag, ignoreCase = true)) {
            languagePreferences.edit().putString(KEY_WORKING_LANGUAGE, languageTag).apply()
            Log.i(TAG, "Idioma compatible recordado: $languageTag")
        }
    }

    private fun createRecognitionListener(sessionId: Long): RecognitionListener {
        return object : RecognitionListener {
            private fun isCurrent(): Boolean = running && activeSessionId == sessionId

            private fun markEvent() {
                if (isCurrent()) lastRecognizerEventAt = SystemClock.elapsedRealtime()
            }

            override fun onReadyForSpeech(params: Bundle?) {
                if (!isCurrent()) return
                markEvent()
                rememberWorkingRecognitionLanguage()
                sendUpdate("Susurro Google listo", "", "", 0)
            }

            override fun onBeginningOfSpeech() {
                if (!isCurrent()) return
                markEvent()
                currentSessionSpeechStarted = true
                // El ruido ambiental puede activar onBeginningOfSpeech. No se conserva
                // ni se extiende una pregunta hasta que Google entregue palabras nuevas.
                sendUpdate("Te estoy escuchando...", "", "", 25)
            }

            override fun onRmsChanged(rmsdB: Float) {
                if (!isCurrent()) return
                markEvent()

                val level = ((rmsdB + 2f) * 8f).toInt().coerceIn(0, 100)
                val now = SystemClock.elapsedRealtime()
                if (
                    now - lastLevelDispatchAt >= LEVEL_UPDATE_INTERVAL_MS ||
                    lastLevelSent < 0 ||
                    abs(level - lastLevelSent) >= 8
                ) {
                    lastLevelDispatchAt = now
                    lastLevelSent = level
                    sendUpdate("", "", "", level)
                }
            }

            override fun onBufferReceived(buffer: ByteArray?) {
                if (!isCurrent()) return
                markEvent()
            }

            override fun onEndOfSpeech() {
                if (!isCurrent()) return
                markEvent()
                sendUpdate("Procesando voz...", "", "", -1)
            }

            override fun onError(error: Int) {
                val partialFallback = lastPartial.trim()
                logLoopState("recognizer_error", sessionId, "error=$error partial=${partialFallback.take(80)}")
                if (!finishSessionIfCurrent(sessionId)) return
                cancelPartialRunnable()

                // Una pregunta reconocida siempre tiene prioridad sobre la recuperación.
                // Si todavía está claramente incompleta, se conserva y se abre una sesión nueva.
                if (partialFallback.isNotBlank() &&
                    (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)
                ) {
                    consecutiveRecognizerErrors = 0
                    handleRecognizedText(partialFallback, "texto parcial tras error $error")
                    return
                }

                if (dispatchAvailableQuestionBeforeRecovery(partialFallback, "error $error")) return

                if (partialFallback.isNotBlank()) {
                    handleRecognizedText(partialFallback, "texto parcial tras error $error")
                    return
                }

                if (error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED ||
                    error == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE
                ) {
                    consecutiveRecognizerErrors = 0
                    val rejectedLanguage = currentRecognitionLanguage()
                    languagePreferences.edit().remove(KEY_WORKING_LANGUAGE).apply()
                    val nextLanguage = advanceRecognitionLanguage()
                    if (nextLanguage != null) {
                        Log.w(TAG, "Idioma $rejectedLanguage rechazado con error $error; probando $nextLanguage")
                        sendUpdate(
                            "Ajustando idioma de Google interno...",
                            "",
                            "Probando otra variante de espanol.",
                            -1
                        )
                        scheduleFreshSession(700L, "idioma $rejectedLanguage no compatible")
                    } else {
                        Log.e(TAG, "Google rechazo todas las variantes de espanol configuradas")
                        resetRecognitionLanguageCycle()
                        sendUpdate(
                            "Google interno sin idioma disponible",
                            "",
                            "Reintentando con el idioma compatible del telefono.",
                            -1
                        )
                        scheduleFreshSession(5000L, "reinicio de idiomas")
                    }
                    return
                }

                val delay = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                        consecutiveRecognizerErrors = 0
                        sendUpdate("No detecto voz", "", "", -1)
                        600L
                    }

                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                        consecutiveRecognizerErrors += 1
                        sendUpdate("Google interno ocupado", "", "Reabriendo escucha.", -1)
                        1400L
                    }

                    SpeechRecognizer.ERROR_TOO_MANY_REQUESTS -> {
                        consecutiveRecognizerErrors += 1
                        sendUpdate("Google interno en pausa breve", "", "Reintentando automáticamente.", -1)
                        5000L
                    }

                    SpeechRecognizer.ERROR_SERVER_DISCONNECTED,
                    SpeechRecognizer.ERROR_SERVER,
                    SpeechRecognizer.ERROR_NETWORK,
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> {
                        consecutiveRecognizerErrors += 1
                        sendUpdate("Reconectando Google interno...", "", "", -1)
                        2500L
                    }

                    else -> {
                        consecutiveRecognizerErrors += 1
                        sendUpdate("Google interno error $error", "", "Reintentando escucha.", -1)
                        if (consecutiveRecognizerErrors >= 3) 2500L else 1200L
                    }
                }

                scheduleFreshSession(delay, "error $error")
            }

            override fun onResults(results: Bundle?) {
                logLoopState("recognizer_results", sessionId)
                if (!finishSessionIfCurrent(sessionId)) return
                cancelPartialRunnable()
                consecutiveRecognizerErrors = 0

                val matches = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    .orEmpty()

                val confidenceScores = results?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)
                val finalCandidate = chooseBestSpeechCandidate(matches, confidenceScores)
                val best = when {
                    finalCandidate.isBlank() -> lastPartial.trim()
                    lastPartial.isBlank() -> finalCandidate
                    else -> SpeechTranscriptMerger.mergePartialWithFinal(lastPartial, finalCandidate)
                }

                if (best.isBlank()) {
                    if (pendingNormalQuestion.isNotBlank()) {
                        finalizePendingNormalQuestion("resultado vacío en confirmación")
                    } else if (continuationBuffer.isNotBlank()) {
                        scheduleFreshSession(400L, "continuación sin resultado")
                    } else {
                        scheduleFreshSession(500L, "resultado vacío")
                    }
                    return
                }

                handleRecognizedText(best, "resultado final")
            }

            override fun onPartialResults(partialResults: Bundle?) {
                if (!isCurrent()) return
                markEvent()

                val partial = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                    .trim()

                if (partial.isBlank()) return

                val previousPartial = lastPartial
                lastPartial = SpeechTranscriptMerger.selectSessionHypothesis(lastPartial, partial)
                val textChanged = ResponseRepository.normalize(previousPartial) !=
                    ResponseRepository.normalize(lastPartial)
                if (textChanged) {
                    currentSessionLastTextAt = SystemClock.elapsedRealtime()
                }

                val preview = mergeWithContinuation(lastPartial)
                sendUpdate(
                    "Escuchando...",
                    preview,
                    "",
                    -1
                )
                schedulePartialFallback(sessionId)
            }

            override fun onEvent(eventType: Int, params: Bundle?) {
                if (!isCurrent()) return
                markEvent()
            }
        }
    }

    private fun finishSessionIfCurrent(sessionId: Long): Boolean {
        if (activeSessionId != sessionId) return false
        activeSessionId = 0L
        isListening = false
        cancelSessionWatchdog()
        destroyRecognizerOnly()
        return true
    }

    private fun destroyRecognizerOnly() {
        val old = recognizer
        recognizer = null
        if (old != null) {
            runCatching { old.cancel() }
                .onFailure { Log.d(TAG, "El reconocedor ya estaba cancelado", it) }
            runCatching { old.destroy() }
                .onFailure { Log.w(TAG, "No se pudo destruir SpeechRecognizer", it) }
        }
    }

    private fun scheduleSessionWatchdog(sessionId: Long, timeoutMs: Long = SESSION_HARD_TIMEOUT_MS) {
        cancelSessionWatchdog()
        val watchdog = Runnable {
            sessionWatchdogRunnable = null
            if (!running || isSpeaking || isProcessing || activeSessionId != sessionId) return@Runnable

            val partialFallback = lastPartial.trim()
            Log.w(TAG, "Sesion Google $sessionId sin cierre; evaluando texto antes de recuperar")
            finishSessionIfCurrent(sessionId)

            if (dispatchAvailableQuestionBeforeRecovery(partialFallback, "watchdog de sesión")) {
                return@Runnable
            }

            if (partialFallback.isNotBlank()) {
                handleRecognizedText(partialFallback, "watchdog con texto")
            } else if (continuationBuffer.isNotBlank()) {
                sendUpdate("Esperando que completes la pregunta...", continuationBuffer, "", -1)
                scheduleFreshSession(500L, "watchdog con continuación")
            } else {
                sendUpdate("Reiniciando escucha...", "", "", -1)
                scheduleFreshSession(700L, "watchdog de sesión")
            }
        }
        sessionWatchdogRunnable = watchdog
        handler.postDelayed(watchdog, timeoutMs)
    }

    private fun cancelSessionWatchdog() {
        sessionWatchdogRunnable?.let { handler.removeCallbacks(it) }
        sessionWatchdogRunnable = null
    }

    private fun startLoopSupervisor() {
        loopSupervisorRunnable?.let { handler.removeCallbacks(it) }
        val supervisor = object : Runnable {
            override fun run() {
                renewWakeLockIfNeeded()
                if (running && !isSpeaking && !isProcessing && !questionDispatchInFlight.get()) {
                    val now = SystemClock.elapsedRealtime()
                    val awaitingConfirmation = pendingNormalQuestion.isNotBlank() &&
                        pendingNormalQuestionRunnable != null
                    val noSessionScheduled = !isListening && pendingStartRunnable == null &&
                        !awaitingConfirmation
                    val staleSession = isListening && activeSessionId != 0L &&
                        lastRecognizerEventAt > 0L &&
                        now - lastRecognizerEventAt > SUPERVISOR_STALE_EVENT_MS

                    when {
                        staleSession -> {
                            val currentSession = activeSessionId
                            val partialFallback = lastPartial.trim()
                            logLoopState(
                                "supervisor_stale_session",
                                currentSession,
                                "gapMs=${now - lastRecognizerEventAt}"
                            )
                            if (currentSession != 0L) finishSessionIfCurrent(currentSession)

                            if (!dispatchAvailableQuestionBeforeRecovery(partialFallback, "supervisor sin eventos")) {
                                if (partialFallback.isNotBlank()) {
                                    handleRecognizedText(partialFallback, "supervisor con texto")
                                } else {
                                    sendUpdate("Recuperando Google interno...", "", "", -1)
                                    scheduleFreshSession(700L, "supervisor sin eventos")
                                }
                            }
                        }

                        noSessionScheduled -> {
                            logLoopState("supervisor_loop_stopped")
                            scheduleFreshSession(250L, "supervisor sin sesión")
                        }
                    }
                }

                if (running) handler.postDelayed(this, LOOP_SUPERVISOR_INTERVAL_MS)
            }
        }
        loopSupervisorRunnable = supervisor
        handler.postDelayed(supervisor, LOOP_SUPERVISOR_INTERVAL_MS)
    }

    private fun schedulePartialFallback(sessionId: Long) {
        cancelPartialRunnable()
        val runnable = Runnable {
            partialRunnable = null
            if (!running || isSpeaking || isProcessing || activeSessionId != sessionId) return@Runnable

            val fallback = lastPartial.trim()
            if (fallback.isBlank() || !finishSessionIfCurrent(sessionId)) return@Runnable
            handleRecognizedText(fallback, "texto parcial estable")
        }
        partialRunnable = runnable
        handler.postDelayed(runnable, PARTIAL_FALLBACK_MS)
    }

    private fun scheduleNormalQuestionConfirmation(raw: String) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { scheduleNormalQuestionConfirmation(raw) }
            return
        }
        if (!running || isSpeaking || isProcessing || questionDispatchInFlight.get()) return

        val candidate = VoiceQuestionNormalizer.normalize(raw).trim()
        if (candidate.isBlank()) {
            scheduleFreshSession(350L, "pregunta normal vacía")
            return
        }

        cancelPendingNormalQuestion()
        pendingNormalQuestion = candidate
        val confirmationId = ++pendingNormalQuestionSerial
        sendUpdate(
            "Confirmando pregunta...",
            candidate,
            "",
            -1
        )

        val runnable = Runnable {
            if (confirmationId != pendingNormalQuestionSerial) return@Runnable
            pendingNormalQuestionRunnable = null
            finalizePendingNormalQuestion("pregunta estable")
        }
        pendingNormalQuestionRunnable = runnable
        handler.postDelayed(runnable, confirmationDelayMs(candidate))
        logLoopState("question_confirmation", extra = "id=$confirmationId text=${candidate.take(80)}")
    }



    private fun finalizePendingNormalQuestion(reason: String) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { finalizePendingNormalQuestion(reason) }
            return
        }
        if (!running || isSpeaking || isProcessing || questionDispatchInFlight.get()) return

        val candidate = pendingNormalQuestion.trim()
        if (candidate.isBlank()) {
            cancelPendingNormalQuestion()
            scheduleFreshSession(350L, "confirmación vacía")
            return
        }

        if (!dispatchRecognizedQuestion(candidate, reason)) {
            val pending = takePendingNormalQuestion()
            if (pending.isNotBlank()) {
                continuationBuffer = mergeWithContinuation(pending)
                sendUpdate("Pregunta incompleta; continúa...", continuationBuffer, "", -1)
            }
            scheduleFreshSession(350L, "confirmación sin pregunta útil")
        }
    }

    /**
     * Punto unico de decision antes de cualquier recuperacion. Si existe texto
     * util, se procesa. Solo se permite reconectar cuando no hay una pregunta
     * despachable. Todos los watchdogs y errores pasan por esta funcion.
     */
    private fun dispatchAvailableQuestionBeforeRecovery(
        partialFallback: String,
        reason: String
    ): Boolean {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { dispatchAvailableQuestionBeforeRecovery(partialFallback, reason) }
            return true
        }
        if (!running || isSpeaking || isProcessing || questionDispatchInFlight.get()) {
            return false
        }

        val candidate = selectDispatchableQuestion(partialFallback)
        if (candidate.isBlank()) {
            logLoopState("no_dispatchable_question", extra = "reason=$reason partial=${partialFallback.take(80)}")
            return false
        }

        return dispatchRecognizedQuestion(candidate, reason)
    }

    private fun selectDispatchableQuestion(partialFallback: String): String {
        val pendingCandidate = pendingNormalQuestion.trim()
        val continuedCandidate = mergeWithContinuation(partialFallback)
        val partialCandidate = partialFallback.trim()

        return listOf(pendingCandidate, continuedCandidate, partialCandidate)
            .firstOrNull { isDispatchableQuestion(it) }
            .orEmpty()
    }

    /**
     * Entrega una pregunta una sola vez. El guard atomico se activa antes de
     * cancelar el reconocedor, de modo que callbacks tardios, watchdogs o errores
     * no puedan reconectar ni duplicar la misma pregunta.
     */
    private fun dispatchRecognizedQuestion(raw: String, reason: String): Boolean {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { dispatchRecognizedQuestion(raw, reason) }
            return true
        }
        if (!running || isSpeaking || isProcessing) return false

        val candidate = VoiceQuestionNormalizer.normalize(raw).trim()
        if (!isDispatchableQuestion(candidate)) return false

        if (!questionDispatchInFlight.compareAndSet(false, true)) {
            logLoopState("duplicate_dispatch_blocked", extra = "reason=$reason text=${candidate.take(80)}")
            return true
        }

        isProcessing = true
        cancelPendingStart()
        cancelSessionWatchdog()
        cancelPartialRunnable()

        val currentSession = activeSessionId
        if (currentSession != 0L) {
            finishSessionIfCurrent(currentSession)
        } else {
            activeSessionId = 0L
            isListening = false
            destroyRecognizerOnly()
        }

        cancelPendingNormalQuestion()
        continuationBuffer = ""
        lastPartial = ""
        currentSessionLastTextAt = 0L
        currentSessionSpeechStarted = false

        logLoopState("question_dispatch", extra = "reason=$reason text=${candidate.take(120)}")
        sendUpdate(
            "Procesando pregunta completa...",
            candidate,
            "Pregunta confirmada.",
            -1
        )

        return try {
            processQuestion(candidate)
            true
        } catch (error: Throwable) {
            Log.e(TAG, "Fallo al procesar la pregunta confirmada", error)
            isProcessing = false
            releaseQuestionDispatch("excepcion de procesamiento")
            sendUpdate(
                "No se pudo procesar la pregunta",
                candidate,
                "La escucha se recuperará automáticamente.",
                -1
            )
            scheduleFreshSession(700L, "excepcion de procesamiento")
            true
        }
    }

    private fun releaseQuestionDispatch(reason: String) {
        if (questionDispatchInFlight.compareAndSet(true, false)) {
            logLoopState("dispatch_released", extra = "reason=$reason")
        }
    }

    private fun isDispatchableQuestion(raw: String): Boolean {
        val candidate = VoiceQuestionNormalizer.normalize(raw).trim()
        if (candidate.isBlank()) return false
        if (VoiceQuestionNormalizer.isTooUnclearForJsonOrNet(candidate)) return false
        if (VoiceQuestionNormalizer.isClearlyIncomplete(candidate)) return false
        return true
    }

    private fun takePendingNormalQuestion(): String {
        pendingNormalQuestionSerial += 1L
        pendingNormalQuestionRunnable?.let { handler.removeCallbacks(it) }
        pendingNormalQuestionRunnable = null
        val value = pendingNormalQuestion
        pendingNormalQuestion = ""
        return value
    }

    private fun cancelPendingNormalQuestion() {
        pendingNormalQuestionSerial += 1L
        pendingNormalQuestionRunnable?.let { handler.removeCallbacks(it) }
        pendingNormalQuestionRunnable = null
        pendingNormalQuestion = ""
    }

    private fun mergeWithContinuation(raw: String): String {
        val current = raw.trim()
        return when {
            continuationBuffer.isBlank() -> current
            current.isBlank() -> continuationBuffer.trim()
            else -> SpeechTranscriptMerger.mergeCommitted(continuationBuffer, current).trim()
        }
    }

    private fun handleRecognizedText(raw: String, reason: String): Boolean {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { handleRecognizedText(raw, reason) }
            return true
        }
        if (!running || isSpeaking || isProcessing || questionDispatchInFlight.get()) return false

        val candidate = VoiceQuestionNormalizer.normalize(mergeWithContinuation(raw)).trim()
        if (candidate.isBlank()) {
            continuationBuffer = ""
            scheduleFreshSession(400L, "$reason sin texto")
            return false
        }

        if (VoiceQuestionNormalizer.isTooUnclearForJsonOrNet(candidate)) {
            continuationBuffer = ""
            sendUpdate("No se detectó una pregunta clara", "", "", -1)
            scheduleFreshSession(500L, "$reason poco claro")
            return true
        }

        if (VoiceQuestionNormalizer.isClearlyIncomplete(candidate)) {
            continuationBuffer = candidate
            sendUpdate("Pregunta en pausa; continúa...", candidate, "", -1)
            scheduleFreshSession(350L, "$reason incompleto")
            return true
        }

        continuationBuffer = ""
        scheduleNormalQuestionConfirmation(candidate)
        return true
    }

    private fun confirmationDelayMs(question: String): Long {
        return if (VoiceQuestionNormalizer.requiresExtendedListening(question)) {
            COMPLEX_QUESTION_CONFIRM_MS
        } else {
            NORMAL_QUESTION_CONFIRM_MS
        }
    }

    private fun cancelPartialRunnable() {
        partialRunnable?.let { handler.removeCallbacks(it) }
        partialRunnable = null
    }

    private fun prepareAudioRouteForUsbMic() {
        try {
            val audioManager = getSystemService(AudioManager::class.java) ?: return
            audioManager.mode = AudioManager.MODE_NORMAL
            audioManager.stopBluetoothSco()
            audioManager.isBluetoothScoOn = false
            audioManager.isSpeakerphoneOn = false
        } catch (e: Exception) {
            Log.w(TAG, "No se pudo ajustar la ruta de audio; se usa la ruta actual", e)
        }
    }

    private data class SpeechCandidate(
        val text: String,
        val originalIndex: Int,
        val googleConfidence: Float
    )

    private fun chooseBestSpeechCandidate(
        matches: List<String>,
        confidenceScores: FloatArray?
    ): String {
        val candidates = matches
            .mapIndexedNotNull { index, raw ->
                val normalized = VoiceQuestionNormalizer.normalize(raw.trim())
                if (normalized.isBlank()) return@mapIndexedNotNull null
                SpeechCandidate(
                    text = normalized,
                    originalIndex = index,
                    googleConfidence = confidenceScores?.getOrNull(index) ?: -1f
                )
            }
            .filter { !VoiceQuestionNormalizer.isTooUnclearForJsonOrNet(it.text) }
            .distinctBy { it.text }

        if (candidates.isEmpty()) {
            return matches.firstNotNullOfOrNull { raw ->
                VoiceQuestionNormalizer.normalize(raw.trim()).takeIf { it.isNotBlank() }
            }.orEmpty()
        }

        // La transcripcion no se decide por coincidencia con JSON. Ese sesgo podia
        // escoger una alternativa corta que coincidiera con una palabra del banco
        // y borrar el inicio real de la pregunta. JSON se consulta despues, con la
        // pregunta completa ya elegida.
        return candidates.maxWithOrNull(
            compareBy<SpeechCandidate> { transcriptionCompletenessScore(it.text) }
                .thenBy { it.googleConfidence }
                .thenBy { -it.originalIndex }
        )?.text.orEmpty()
    }

    private fun transcriptionCompletenessScore(text: String): Int {
        val normalized = VoiceQuestionNormalizer.normalize(text)
        val words = normalized.split(" ").count { it.isNotBlank() }
        var score = words * 10
        if (!VoiceQuestionNormalizer.isClearlyIncomplete(normalized)) score += 4
        if (VoiceQuestionNormalizer.requiresExtendedListening(normalized)) score += 6
        if (
            normalized.startsWith("que ") || normalized.startsWith("cual ") ||
            normalized.startsWith("por que ") || normalized.startsWith("explica ") ||
            normalized.startsWith("completa ")
        ) score += 8
        return score
    }

    private fun processQuestion(raw: String) {
        val question = VoiceQuestionNormalizer.normalize(raw)

        if (VoiceQuestionNormalizer.isTooUnclearForJsonOrNet(question)) {
            isProcessing = false
            releaseQuestionDispatch("pregunta poco clara")
            sendUpdate(
                "No se detectó una pregunta completa",
                question,
                "No se envió a JSON ni a NET. Repite o completa la pregunta.",
                -1
            )
            scheduleFreshSession(650L, "pregunta incompleta")
            return
        }

        if (VoiceQuestionNormalizer.isClearlyIncomplete(question)) {
            isProcessing = false
            releaseQuestionDispatch("pregunta incompleta")
            continuationBuffer = mergeWithContinuation(question)
            sendUpdate("Pregunta incompleta; continúa...", continuationBuffer, "", -1)
            scheduleFreshSession(350L, "continuar pregunta incompleta")
            return
        }

        if (shouldIgnoreOwnVoice(question)) {
            isProcessing = false
            releaseQuestionDispatch("eco de voz")
            scheduleFreshSession(350L, "voz propia")
            return
        }

        val now = System.currentTimeMillis()
        if (question == lastHeard && now - lastHeardTime < 4500) {
            isProcessing = false
            releaseQuestionDispatch("pregunta duplicada")
            scheduleFreshSession(350L, "pregunta duplicada")
            return
        }

        lastHeard = question
        lastHeardTime = now
        enterProcessingState(question)

        val localAnswer = LocalAnswerProvider.findAnswer(question)
        if (localAnswer != null) {
            memory.saveLast(question, localAnswer, "local", 100)
            speakAnswer(question, localAnswer)
            return
        }

        val mode = modeSettings.getMode()
        if (mode == AnswerModeSettings.Mode.INTERNET) {
            if (VoiceQuestionNormalizer.isUnsafeForNet(question)) {
                speakAnswer(question, "No hay una pregunta clara para enviar a NET.")
            } else {
                answerOnline(question)
            }
            return
        }

        answerRoutedInBackground(question, mode)
    }

    private fun enterProcessingState(question: String) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { enterProcessingState(question) }
            return
        }

        cancelPendingNormalQuestion()
        isProcessing = true
        isListening = false
        cancelPendingStart()
        cancelSessionWatchdog()
        cancelPartialRunnable()
        activeSessionId = 0L
        destroyRecognizerOnly()
        sendUpdate("Procesando...", question, "", -1)
    }

    private fun answerRoutedInBackground(question: String, mode: AnswerModeSettings.Mode) {
        val status = if (mode == AnswerModeSettings.Mode.AUTO) {
            "Buscando en JSON; si no encuentra, pasa a NET..."
        } else {
            "Buscando solo en JSON..."
        }
        sendUpdate(status, question, "Procesando sin bloquear la app.", -1)

        synchronized(backgroundLock) {
            routeFuture?.cancel(true)
            routeFuture = routeExecutor.submit {
                val route = try {
                    questionRouter.resolve(mode, question)
                } catch (e: Exception) {
                    Log.e(TAG, "Fallo inesperado al buscar en JSON/AUTO", e)
                    handler.post {
                        if (running) speakAnswer(question, "No se pudo procesar la pregunta. Inténtalo nuevamente.")
                    }
                    return@submit
                }
                if (!running || Thread.currentThread().isInterrupted) return@submit

                when (route) {
                    is QuestionRouter.Result.Json -> {
                        val match = route.match
                        memory.saveLast(question, match.answer, match.itemId, match.score)
                        handler.post { if (running) speakAnswer(question, match.answer) }
                    }

                    QuestionRouter.Result.JsonNotFound -> {
                        handler.post { if (running) speakAnswer(question, "No encontrado") }
                    }

                    QuestionRouter.Result.Net -> {
                        if (VoiceQuestionNormalizer.isUnsafeForNet(question)) {
                            handler.post { if (running) speakAnswer(question, "No hay una pregunta clara para enviar a NET.") }
                        } else {
                            answerOnline(question)
                        }
                    }
                }
            }
        }
    }

    private fun warmJsonInBackground() {
        synchronized(backgroundLock) {
            routeFuture = routeExecutor.submit {
                try {
                    jsonRepository.totalItems
                } catch (e: Exception) {
                    Log.e(TAG, "No se pudo precargar el JSON", e)
                }
            }
        }
    }

    private fun answerOnline(question: String, statusText: String = "Buscando NET...") {
        sendUpdate(statusText, question, "Buscando una API probada; si falla, pasa a la siguiente.", -1)
        val requestVersion = ++onlineRequestVersion

        synchronized(backgroundLock) {
            netFuture?.cancel(true)
            onlineProvider.cancelActiveRequest()
            netFuture = netExecutor.submit {
                val answer = try {
                    onlineProvider.fetchShortAnswer(question)
                } catch (e: Exception) {
                    Log.e(TAG, "Fallo inesperado al consultar NET", e)
                    "NET no pudo responder. Revisa Internet y el estado de tus APIs."
                }

                if (!running || requestVersion != onlineRequestVersion || Thread.currentThread().isInterrupted) {
                    return@submit
                }
                memory.saveLast(question, answer, "online", 0)
                handler.post {
                    if (running && requestVersion == onlineRequestVersion) {
                        speakAnswer(question, answer)
                    }
                }
            }
        }
    }

    private fun speakAnswer(question: String, answer: String) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { speakAnswer(question, answer) }
            return
        }
        if (!running) return

        val finalAnswer = OnlineAnswerProvider.canonicalizeAnswerForQuestion(question, answer)
            .ifBlank { answer.trim() }

        cancelPendingNormalQuestion()
        isProcessing = false
        isSpeaking = true
        isListening = false
        cancelPendingStart()
        cancelSessionWatchdog()
        cancelPartialRunnable()
        cancelPendingNormalQuestion()
        continuationBuffer = ""
        activeSessionId = 0L
        destroyRecognizerOnly()

        lastSpokenNormalized = ResponseRepository.normalize(finalAnswer)
        sendUpdate("Respuesta lista", question, finalAnswer, -1)

        val utteranceId = "${UTTERANCE_ID_PREFIX}_${++speechSerial}"
        activeUtteranceId = utteranceId
        speechStartedAt = SystemClock.elapsedRealtime()
        cancelTtsWatchdog()
        cancelTtsStateMonitor()
        postSpeechGuardRunnable?.let { handler.removeCallbacks(it) }
        postSpeechGuardRunnable = null

        tts?.stop()
        tts?.setSpeechRate(appSettings.getVoiceRate())

        val result = tts?.speak(finalAnswer, TextToSpeech.QUEUE_FLUSH, null, utteranceId) ?: TextToSpeech.ERROR
        if (result == TextToSpeech.ERROR) {
            finishSpeakingAndResume(utteranceId, "error al iniciar voz")
            return
        }

        scheduleTtsWatchdog(utteranceId, finalAnswer)
        scheduleTtsStateMonitor(utteranceId)
    }

    private fun scheduleTtsStateMonitor(utteranceId: String) {
        cancelTtsStateMonitor()
        val monitor = object : Runnable {
            override fun run() {
                if (!running || activeUtteranceId != utteranceId || !isSpeaking) {
                    ttsStateMonitorRunnable = null
                    return
                }

                val elapsed = SystemClock.elapsedRealtime() - speechStartedAt
                val engineStillSpeaking = runCatching { tts?.isSpeaking == true }.getOrDefault(false)
                if (elapsed >= TTS_START_GRACE_MS && !engineStillSpeaking) {
                    ttsStateMonitorRunnable = null
                    finishSpeakingAndResume(utteranceId, "lector de voz terminado")
                    return
                }

                handler.postDelayed(this, TTS_STATE_CHECK_INTERVAL_MS)
            }
        }
        ttsStateMonitorRunnable = monitor
        handler.postDelayed(monitor, TTS_STATE_CHECK_INTERVAL_MS)
    }

    private fun cancelTtsStateMonitor() {
        ttsStateMonitorRunnable?.let { handler.removeCallbacks(it) }
        ttsStateMonitorRunnable = null
    }

    private fun scheduleTtsWatchdog(utteranceId: String, answer: String) {
        cancelTtsWatchdog()
        val rate = appSettings.getVoiceRate().coerceIn(0.35f, 2.5f)
        val wordCount = answer.trim().split(Regex("\\s+")).count { it.isNotBlank() }.coerceAtLeast(1)
        val estimatedMs = ((wordCount * 720L) / rate).toLong() + 8000L
        val timeoutMs = estimatedMs.coerceIn(12000L, 120000L)

        val watchdog = Runnable {
            ttsWatchdogRunnable = null
            if (!running || activeUtteranceId != utteranceId || !isSpeaking) return@Runnable

            Log.w(TAG, "TTS sin onDone; recuperando escucha")
            runCatching { tts?.stop() }
            finishSpeakingAndResume(utteranceId, "watchdog de voz")
        }
        ttsWatchdogRunnable = watchdog
        handler.postDelayed(watchdog, timeoutMs)
    }

    private fun cancelTtsWatchdog() {
        ttsWatchdogRunnable?.let { handler.removeCallbacks(it) }
        ttsWatchdogRunnable = null
    }

    private fun finishSpeakingAndResume(utteranceId: String, reason: String) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { finishSpeakingAndResume(utteranceId, reason) }
            return
        }
        if (activeUtteranceId != utteranceId) return

        cancelTtsWatchdog()
        cancelTtsStateMonitor()
        activeUtteranceId = null
        isProcessing = false
        isSpeaking = false
        releaseQuestionDispatch(reason)
        resetQuestionCycleState()
        sendUpdate("Volviendo a escuchar...", "", "", -1, clearFields = true)
        scheduleFreshSession(350L, reason)

        // Garantia adicional: tras terminar la respuesta, la escucha debe haberse
        // reabierto antes de tres segundos. Si no, se fuerza una sesion nueva.
        postSpeechGuardRunnable?.let { handler.removeCallbacks(it) }
        val guard = Runnable {
            postSpeechGuardRunnable = null
            if (running && !isSpeaking && !isProcessing && !isListening) {
                Log.w(TAG, "La escucha no volvio tras la respuesta; forzando reinicio")
                scheduleFreshSession(180L, "guardia posterior a respuesta")
            }
        }
        postSpeechGuardRunnable = guard
        handler.postDelayed(guard, POST_SPEECH_MAX_RETURN_MS)
    }

    private fun resetQuestionCycleState() {
        cancelPendingNormalQuestion()
        cancelPartialRunnable()
        continuationBuffer = ""
        lastPartial = ""
        currentSessionLastTextAt = 0L
        currentSessionSpeechStarted = false
        lastHeard = ""
        lastHeardTime = 0L
        questionDispatchInFlight.set(false)
        activeSessionId = 0L
        isListening = false
    }

    private fun shouldIgnoreOwnVoice(question: String): Boolean {
        val spoken = lastSpokenNormalized
        if (question.isBlank() || spoken.isBlank()) return false
        if (spoken.contains(question) && question.length >= 8) return true

        val qWords = question.split(" ").filter { it.length >= 4 }
        if (qWords.isEmpty()) return false
        val spokenWords = spoken.split(" ").toSet()
        val common = qWords.count { it in spokenWords }
        return common >= 3 && common >= qWords.size * 0.6
    }

    private fun restartRecognizer(delayMs: Long) {
        scheduleFreshSession(delayMs, "reinicio solicitado")
    }

    private fun logLoopState(
        event: String,
        sessionId: Long = activeSessionId,
        extra: String = ""
    ) {
        Log.i(
            TAG,
            "GSU_STATE event=$event session=$sessionId running=$running " +
                "listening=$isListening processing=$isProcessing speaking=$isSpeaking " +
                "dispatch=${questionDispatchInFlight.get()} pending=${pendingNormalQuestion.isNotBlank()} " +
                "continuation=${continuationBuffer.isNotBlank()} partial=\"${lastPartial.take(60)}\" $extra"
        )
    }

    private fun sendUpdate(
        status: String,
        heard: String,
        answer: String,
        level: Int,
        clearFields: Boolean = false
    ) {
        val intent = Intent(ACTION_UPDATE).apply {
            putExtra(EXTRA_STATUS, status)
            putExtra(EXTRA_HEARD, heard)
            putExtra(EXTRA_ANSWER, answer)
            putExtra(EXTRA_LEVEL, level)
            putExtra(EXTRA_CLEAR_FIELDS, clearFields)
        }
        sendBroadcast(intent)

        if (status.isNotBlank()) {
            getSystemService(NotificationManager::class.java)
                .notify(NOTIFICATION_ID, buildNotification(status))
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Geo Susu Google Interno",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentTitle("Geo Susu")
        .setContentText(text.take(90))
        .setOngoing(true)
        .build()

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GeoSusuAudio::GoogleInternalWakeLock").apply {
            setReferenceCounted(false)
            acquire(WAKE_LOCK_DURATION_MS)
        }
    }

    private fun renewWakeLockIfNeeded() {
        if (wakeLock?.isHeld == true) return
        runCatching { acquireWakeLock() }
            .onFailure { Log.w(TAG, "No se pudo renovar WakeLock", it) }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.setLanguage(Locale("es", "PE"))
            tts?.setSpeechRate(appSettings.getVoiceRate())
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit

                override fun onDone(utteranceId: String?) {
                    if (utteranceId != null) {
                        handler.post { finishSpeakingAndResume(utteranceId, "respuesta terminada") }
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    if (utteranceId != null) {
                        handler.post { finishSpeakingAndResume(utteranceId, "error de voz") }
                    }
                }
            })
        }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            // El JSON se reconstruye cuando vuelva a necesitarse; no se pierde ningun dato.
            JsonKnowledgeRepository.clearMemoryCache()
            Log.i(TAG, "Memoria baja: se liberaron indices reconstruibles del JSON")
        }
    }

    override fun onLowMemory() {
        super.onLowMemory()
        JsonKnowledgeRepository.clearMemoryCache()
        Log.w(TAG, "Android solicito liberar memoria")
    }

    override fun onDestroy() {
        running = false
        onlineRequestVersion += 1
        onlineProvider.cancelActiveRequest()
        synchronized(backgroundLock) {
            routeFuture?.cancel(true)
            netFuture?.cancel(true)
            routeFuture = null
            netFuture = null
        }
        routeExecutor.shutdownNow()
        netExecutor.shutdownNow()

        cancelPendingStart()
        cancelSessionWatchdog()
        loopSupervisorRunnable?.let { handler.removeCallbacks(it) }
        loopSupervisorRunnable = null
        cancelPartialRunnable()
        continuationBuffer = ""
        cancelTtsWatchdog()
        cancelTtsStateMonitor()
        postSpeechGuardRunnable?.let { handler.removeCallbacks(it) }
        postSpeechGuardRunnable = null

        activeSessionId = 0L
        isListening = false
        isProcessing = false
        isSpeaking = false
        questionDispatchInFlight.set(false)
        destroyRecognizerOnly()

        runCatching { tts?.stop() }
        runCatching { tts?.shutdown() }

        runCatching {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        }.onFailure { Log.w(TAG, "No se pudo liberar WakeLock", it) }

        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_UPDATE = "com.bph.geosusuaudio.GOOGLE_INTERNAL_UPDATE"
        const val EXTRA_STATUS = "status"
        const val EXTRA_HEARD = "heard"
        const val EXTRA_ANSWER = "answer"
        const val EXTRA_LEVEL = "level"
        const val EXTRA_CLEAR_FIELDS = "clear_fields"

        private const val CHANNEL_ID = "geo_susu_google_internal_channel"
        private const val NOTIFICATION_ID = 6001
        private const val UTTERANCE_ID_PREFIX = "geo_susu_google_internal_answer"
        private const val TAG = "GeoSusuGoogle"

        private const val RECOGNIZER_SETTLE_DELAY_MS = 250L
        private const val SESSION_HARD_TIMEOUT_MS = 18000L
        private const val LOOP_SUPERVISOR_INTERVAL_MS = 5000L
        private const val SUPERVISOR_STALE_EVENT_MS = 45000L
        private const val LEVEL_UPDATE_INTERVAL_MS = 250L
        private const val PARTIAL_FALLBACK_MS = 3000L
        private const val NORMAL_QUESTION_CONFIRM_MS = 1800L
        private const val COMPLEX_QUESTION_CONFIRM_MS = 2700L
        private const val POST_SPEECH_MAX_RETURN_MS = 2800L
        private const val TTS_STATE_CHECK_INTERVAL_MS = 500L
        private const val TTS_START_GRACE_MS = 3000L
        private const val WAKE_LOCK_DURATION_MS = 8L * 60L * 60L * 1000L
        private const val LANGUAGE_PREFS_NAME = "google_internal_language_preferences"
        private const val KEY_WORKING_LANGUAGE = "working_language_tag"
    }
}
