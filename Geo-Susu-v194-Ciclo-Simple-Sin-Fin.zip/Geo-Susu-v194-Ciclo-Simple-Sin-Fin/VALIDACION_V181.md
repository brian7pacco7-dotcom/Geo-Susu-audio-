# Geo Susu v181 - Cierre por texto y pegado de APIs

Cambios aplicados sobre v180:

- Botón PEGAR al costado de Gemini, OpenRouter, Mistral y Cohere.
- El pegado toma el portapapeles, recorta espacios y no agrega la clave automáticamente.
- Las preguntas se cierran tras 3 segundos sin palabras nuevas; el ruido RMS no reinicia el contador.
- onBeginningOfSpeech ya no conserva ni amplía preguntas solo por ruido de fondo.
- La orden fin se detecta también en resultados parciales y cierra de inmediato.
- Antes de cerrar una pregunta larga se conserva el último parcial reconocido.
- Al terminar o fallar el TTS se limpian pregunta, respuesta, parciales y temporizadores antes de volver a escuchar.
- Los callbacks antiguos siguen aislados por identificador de sesión.
- No se modificaron la sensibilidad, los tiempos 4200/2600/2600, JSON, Vosk, rotación de APIs ni la interfaz principal.
