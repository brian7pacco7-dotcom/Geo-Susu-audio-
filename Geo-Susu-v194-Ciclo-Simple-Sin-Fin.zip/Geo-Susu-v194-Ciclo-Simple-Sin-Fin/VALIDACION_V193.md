# Geo Susu v193 - Coordinación estable del ciclo Google

## Objetivo
Corregir el bloqueo en el que Google reconoce una pregunta, la deja visible y luego reconecta sin enviarla a procesar.

## Cambios aplicados
- Una pregunta normal completa ya no abre una segunda sesión de Google durante la ventana de confirmación.
- La confirmación dura 2 segundos y luego despacha la pregunta automáticamente.
- Se agregó un guard atómico para que una pregunta solo pueda enviarse una vez.
- Los reinicios pendientes, confirmaciones y temporizadores largos usan identificadores para ignorar tareas antiguas.
- Antes de cualquier recuperación se busca primero una pregunta válida pendiente.
- El supervisor no interviene durante la confirmación ni durante el procesamiento.
- La recuperación secundaria por sesión sin eventos queda como respaldo a 45 segundos; el watchdog principal conserva su función.
- El WakeLock se renueva automáticamente durante el ciclo prolongado.
- Los avisos de memoria baja ya no borran el texto parcial de una pregunta activa.
- Se añadieron trazas `GSU_STATE` para identificar sesión, procesamiento, voz, despacho y recuperación.

## Funciones conservadas
- Reconocimiento Google interno y tiempos 4200/2600/2600.
- Sensibilidad y nivel de voz.
- JSON, NET y AUTO.
- APIs y rotación.
- TTS, Vosk y micrófono externo.
- Pantalla fijada y doble confirmación de salida.

## Comprobaciones realizadas
- Normalización de `¿Qué día es hoy?` a `que dia es hoy`.
- Respuesta local válida para la fecha actual.
- Clasificación de `diferencia entre canon minero y regalías mineras` como pregunta extendida.
- Verificación estructural de llaves y paréntesis.
- Confirmación de que `processQuestion` solo se invoca desde el despacho único.
- Confirmación de que la ventana de pregunta normal no inicia otra sesión Google.
- Verificación de integridad del ZIP.

## Limitación de validación
No se compiló el APK ni se ejecutó una prueba física de 12-24 horas porque este entorno no dispone del Android SDK ni del celular del usuario. La compilación sigue disponible mediante el flujo de GitHub Actions incluido en el proyecto.
