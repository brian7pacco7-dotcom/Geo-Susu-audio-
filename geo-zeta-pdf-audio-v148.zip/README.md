# Geo Zeta - PDF a Voz y Audio

Lector de PDF para Android con lectura en voz alta (TTS), disponible en
cinco idiomas: espanol, ingles, portugues, hindi e indonesio.

## Funciones

- Lectura en voz alta de PDFs con el motor TTS del propio dispositivo
- Reproduccion en segundo plano con controles en la notificacion
- Zoom independiente por pagina (cada pagina recuerda el suyo)
- Subrayado y marcado de texto sobre la pagina
- Exportar cualquier pagina como imagen PNG
- Reglas de recorte para ignorar encabezados y pies de pagina
- Seleccion de voz, velocidad y region

## Estructura

- `MainActivity.java` - interfaz principal y control general
- `PdfPageView.java` - renderizado de paginas, zoom, marcado
- `TextRepository.java` - extraccion y cache de texto
- `SelectionTextRepository.java` - texto para seleccion manual
- `TtsForegroundService.java` - reproduccion de audio en segundo plano
- `TtsEngineManager.java` - gestion del motor de voz
- `UiStrings.java` - todos los textos en los cinco idiomas

## Compilacion

El proyecto compila por GitHub Actions (`.github/workflows/`), que genera:

- **APK debug** para instalar y probar directamente
- **AAB de release** firmado, listo para subir a Google Play

Para compilar en local hace falta crear un archivo `keystore.properties`
siguiendo el modelo de `keystore.properties.ejemplo`. Ese archivo y el
keystore nunca se suben al repositorio.

## Notas tecnicas

- `minSdk` 23, `targetSdk` 36
- PDFBox (`com.tom-roush:pdfbox-android`) para leer los PDF
- R8 activado en release; las reglas de `proguard-rules.pro` son
  necesarias para que PDFBox y BouncyCastle no fallen al ofuscar
- Los PDF se abren con el selector del sistema (SAF): no se piden
  permisos de almacenamiento
