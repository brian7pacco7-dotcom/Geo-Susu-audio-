package com.geozeta.pdfaudio;

import android.content.Context;
import android.os.Build;
import android.view.textclassifier.TextClassificationManager;
import android.view.textclassifier.TextClassifier;
import android.view.textclassifier.TextLanguage;

import java.text.Normalizer;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Detects the document language only among the five languages supported by the app.
 * Android's classifier is used when available, with an offline heuristic fallback for
 * older devices and for short text.
 */
public final class PdfLanguageDetector {
    public static final float CONFIDENT_THRESHOLD = 0.64f;

    public static final class Result {
        public final String languageCode;
        public final float confidence;

        Result(String languageCode, float confidence) {
            this.languageCode = languageCode == null ? "" : normalizeCode(languageCode);
            this.confidence = Math.max(0f, Math.min(1f, confidence));
        }

        public boolean isConfident() {
            return isSupported(languageCode) && confidence >= CONFIDENT_THRESHOLD;
        }
    }

    private static final Set<String> SPANISH = words(
            "el la los las de del que y en un una unos unas por para con se es son al como mas su sus esta este estos estas entre sobre tambien puede pueden desde hasta fue han ha lo le les ya pero si no donde cuando cada" );
    private static final Set<String> PORTUGUESE = words(
            "o a os as de do da dos das que e em um uma uns umas para com nao no na nos nas por se e sao ao aos como mais seu sua seus suas esta este estes estas entre sobre tambem pode podem desde ate foi tem ja mas onde quando cada pelo pela pelos pelas" );
    private static final Set<String> ENGLISH = words(
            "the of and to in a is are for that on with as by this these those be from or an it at not can will was were has have had into about between also may more than which when where each" );
    private static final Set<String> INDONESIAN = words(
            "yang dan di ke dari untuk dengan ini itu pada adalah sebagai tidak dalam oleh akan atau juga dapat karena tersebut antara kepada tetapi lebih saya kami kita mereka telah sudah suatu setiap agar jika saat dimana ketika" );

    private PdfLanguageDetector() {
    }

    public static boolean isSupported(String code) {
        code = normalizeCode(code);
        return UiStrings.ES.equals(code) || UiStrings.EN.equals(code)
                || UiStrings.PT.equals(code) || UiStrings.HI.equals(code)
                || UiStrings.ID.equals(code);
    }

    public static String normalizeCode(String code) {
        if (code == null) return "";
        String value = code.toLowerCase(Locale.ROOT).trim();
        if (value.startsWith("es")) return UiStrings.ES;
        if (value.startsWith("pt")) return UiStrings.PT;
        if (value.startsWith("hi")) return UiStrings.HI;
        if (value.startsWith("id") || value.startsWith("in")) return UiStrings.ID;
        if (value.startsWith("en")) return UiStrings.EN;
        return "";
    }

    public static Result detectFast(String text) {
        if (text == null) return new Result("", 0f);
        String trimmed = text.trim();
        if (trimmed.length() < 4) return new Result("", 0f);

        int devanagari = 0;
        int letters = 0;
        for (int i = 0; i < trimmed.length(); i++) {
            char c = trimmed.charAt(i);
            if (Character.isLetter(c)) letters++;
            if (c >= '\u0900' && c <= '\u097f') devanagari++;
        }
        if (devanagari >= 4 && devanagari >= Math.max(4, letters / 8)) {
            float confidence = Math.min(0.99f, 0.78f + devanagari / 120f);
            return new Result(UiStrings.HI, confidence);
        }

        String lower = trimmed.toLowerCase(Locale.ROOT);
        String normalized = Normalizer.normalize(lower, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "");
        String[] rawTokens = normalized.split("[^a-z]+");
        int tokenCount = 0;
        int es = 0;
        int pt = 0;
        int en = 0;
        int id = 0;
        for (String token : rawTokens) {
            if (token == null || token.length() < 1) continue;
            tokenCount++;
            if (SPANISH.contains(token)) es++;
            if (PORTUGUESE.contains(token)) pt++;
            if (ENGLISH.contains(token)) en++;
            if (INDONESIAN.contains(token)) id++;
        }

        if (containsAny(lower, "\u00f1", "\u00bf", "\u00a1")) es += 4;
        if (containsAny(lower, "\u00e3", "\u00f5", "\u00e7")) pt += 4;
        if (containsWord(normalized, "nao") || containsWord(normalized, "sao")) pt += 3;
        if (containsWord(normalized, "yang") || containsWord(normalized, "dengan")) id += 3;
        if (containsWord(normalized, "the") || containsWord(normalized, "which")) en += 2;
        if (containsWord(normalized, "que") || containsWord(normalized, "del")) es += 2;

        int[] scores = new int[]{es, en, pt, id};
        String[] codes = new String[]{UiStrings.ES, UiStrings.EN, UiStrings.PT, UiStrings.ID};
        int bestIndex = 0;
        int second = Integer.MIN_VALUE;
        for (int i = 1; i < scores.length; i++) {
            if (scores[i] > scores[bestIndex]) bestIndex = i;
        }
        for (int i = 0; i < scores.length; i++) {
            if (i != bestIndex) second = Math.max(second, scores[i]);
        }
        int best = scores[bestIndex];
        if (best <= 0) return new Result("", 0.15f);

        int margin = best - Math.max(0, second);
        float confidence = 0.40f + Math.min(0.30f, best * 0.035f)
                + Math.min(0.24f, margin * 0.055f);
        if (tokenCount < 8) confidence -= 0.18f;
        else if (tokenCount < 16) confidence -= 0.08f;
        if (best < 3) confidence -= 0.10f;
        confidence = Math.max(0.05f, Math.min(0.96f, confidence));
        return new Result(codes[bestIndex], confidence);
    }

    /** Must be called from a worker thread on Android 10+ because the system classifier can be slow. */
    public static Result detect(Context context, String text) {
        Result heuristic = detectFast(text);
        if (context == null || Build.VERSION.SDK_INT < 29 || text == null || text.trim().length() < 48) {
            return heuristic;
        }
        // Strong script/stop-word matches are already reliable enough for the
        // supported five-language set. Avoid invoking the slower system
        // classifier on the Play path when the result is unambiguous.
        if (text.trim().length() >= 120 && heuristic.confidence >= 0.92f) {
            return heuristic;
        }

        Result system = detectWithSystem(context, text);
        if (!isSupported(system.languageCode)) return heuristic;
        if (system.languageCode.equals(heuristic.languageCode)) {
            return new Result(system.languageCode,
                    Math.min(0.99f, Math.max(system.confidence, heuristic.confidence) + 0.08f));
        }
        if (system.confidence >= 0.72f) return system;
        if (heuristic.confidence >= 0.82f) return heuristic;
        if (system.confidence >= 0.58f && heuristic.confidence < CONFIDENT_THRESHOLD) return system;
        return new Result("", Math.max(system.confidence, heuristic.confidence) * 0.75f);
    }

    private static Result detectWithSystem(Context context, String text) {
        if (Build.VERSION.SDK_INT < 29) return new Result("", 0f);
        try {
            String sample = text.trim();
            if (sample.length() > 5000) sample = sample.substring(0, 5000);
            TextClassificationManager manager = context.getSystemService(TextClassificationManager.class);
            if (manager == null) return new Result("", 0f);
            TextClassifier classifier = manager.getTextClassifier();
            if (classifier == null) return new Result("", 0f);
            TextLanguage result = classifier.detectLanguage(
                    new TextLanguage.Request.Builder(sample).build());
            int count = result.getLocaleHypothesisCount();
            Result best = new Result("", 0f);
            for (int i = 0; i < count; i++) {
                android.icu.util.ULocale locale = result.getLocale(i);
                if (locale == null) continue;
                String code = normalizeCode(locale.getLanguage());
                if (!isSupported(code)) continue;
                float confidence = result.getConfidenceScore(locale);
                if (confidence > best.confidence) best = new Result(code, confidence);
            }
            return best;
        } catch (Throwable ignored) {
            return new Result("", 0f);
        }
    }

    private static Set<String> words(String value) {
        return new HashSet<String>(Arrays.asList(value.split("\\s+")));
    }

    private static boolean containsWord(String normalizedText, String word) {
        return (" " + normalizedText.replaceAll("[^a-z]+", " ") + " ").contains(" " + word + " ");
    }

    private static boolean containsAny(String value, String... needles) {
        for (String needle : needles) {
            if (value.contains(needle)) return true;
        }
        return false;
    }
}
