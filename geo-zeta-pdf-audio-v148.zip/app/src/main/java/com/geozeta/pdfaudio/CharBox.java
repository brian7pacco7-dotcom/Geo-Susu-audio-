package com.geozeta.pdfaudio;

public class CharBox {
    public final int page;
    public final int index;
    public final int line;
    public final String text;
    public final float left;
    public final float top;
    public final float right;
    public final float bottom;

    public CharBox(int page, int index, int line, String text, float left, float top, float right, float bottom) {
        this.page = page;
        this.index = index;
        this.line = line;
        this.text = text == null ? "" : text;
        this.left = left;
        this.top = top;
        this.right = right;
        this.bottom = bottom;
    }

    public float centerX() {
        return (left + right) / 2f;
    }

    public float centerY() {
        return (top + bottom) / 2f;
    }
}
