package com.geozeta.pdfaudio;

import android.app.Application;
import android.os.Process;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;

/**
 * Process application entry point.
 *
 * TTS is intentionally not initialized here: Application.onCreate shares the
 * critical startup window with the first Activity and PDF restoration. The
 * Activity warms the engine after the UI/first PDF render, while Play can still
 * initialize it immediately on demand through TtsForegroundService.
 */
public class GeoZetaApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

        // La primera vez que se usa PDFBox en todo el proceso (por ejemplo,
        // recien instalada la app), la libreria copia sus fuentes internas a
        // el almacenamiento propio de la app antes de poder leer nada. Esa
        // copia unica se sentia como una demora al abrir el primer PDF.
        // Se dispara aqui mismo, en un hilo de baja prioridad que no compite
        // con el primer dibujado de la interfaz, para que ya este lista
        // cuando el usuario llega a abrir un documento.
        final Application appContext = this;
        Thread warmup = new Thread(new Runnable() {
            @Override
            public void run() {
                Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
                try {
                    PDFBoxResourceLoader.init(appContext.getApplicationContext());
                } catch (Exception ignored) {
                }
            }
        }, "PdfBoxWarmup");
        warmup.setDaemon(true);
        warmup.start();
    }
}
