package com.geozeta.pdfaudio;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PdfPageView extends View {
    public static final int MARK_STYLE_UNDERLINE_FINE = 0;
    public static final int MARK_STYLE_UNDERLINE_DOUBLE = 1;
    public static final int MARK_STYLE_UNDERLINE_WAVY = 2;
    public static final int MARK_STYLE_UNDERLINE_DOTTED = 3;
    public static final int MARK_STYLE_HIGHLIGHT_SOFT = 4;
    public static final int MARK_STYLE_HIGHLIGHT_INTENSE = 5;
    public static final int MARK_STYLE_TEXT_BOX = 6;
    public interface PageChangeListener {
        void onPageRendered(int pageIndex, int pageCount);
        void onError(String message);
        void onHighlightsChanged(String serialized);
        void onRulesChanged(boolean enabled, float top, float bottom);
    }

    public interface DocumentOpenCallback {
        void onOpened(int pageCount);
        void onError(Exception error);
    }


    private static class TextMarker {
        int page;
        int color;
        float left;
        float top;
        float right;
        float bottom;
        int style;
        int thickness;

        TextMarker(int page, int color, float left, float top, float right, float bottom, int style, int thickness) {
            this.page = page;
            this.color = color;
            this.left = left;
            this.top = top;
            this.right = right;
            this.bottom = bottom;
            this.style = safeStyle(style);
            this.thickness = safeThickness(thickness);
        }
    }

    private final Paint paint;
    private final Paint markerPaint;
    private final Paint previewPaint;
    private final Paint rulePaint;
    private final Paint blockedPaint;
    private final ExecutorService executor;

    private PdfRenderer renderer;
    private ParcelFileDescriptor descriptor;
    private Bitmap bitmap;
    private int pageIndex;
    private int pageCount;
    private boolean renderBusy;
    private int pendingPage;
    private int serial;
    private volatile int documentOpenSerial;

    private float zoom;
    private float panX;
    private float panY;

    /**
     * Zoom y posicion guardados por pagina. Solo se guarda la pagina que el
     * usuario dejo agrandada; si la dejo en su tamano normal, no se guarda nada
     * y al volver se ve completa como siempre.
     */
    private final Map<Integer, float[]> pageViewStates =
            new java.util.LinkedHashMap<Integer, float[]>(16, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<Integer, float[]> eldest) {
                    return size() > 80;
                }
            };
    /** Pagina a la que pertenece el bitmap que se esta viendo ahora mismo. */
    private int renderedPageIndex = -1;
    /**
     * Zoom y posicion que se van a aplicar cuando la pagina pedida termine de
     * dibujarse. No se aplican antes: hacerlo movia la pagina vieja que todavia
     * estaba en pantalla, y ese era el tiron que se veia al cambiar de pagina.
     */
    private boolean hasPendingViewState;
    private int pendingViewStatePage = -1;
    private float pendingZoom = 1.0f;
    private float pendingPanX;
    private float pendingPanY;

    private PageChangeListener listener;
    private final ScaleGestureDetector scaleDetector;
    private final GestureDetector gestureDetector;
    private final Object lock = new Object();

    private boolean markMode;
    private int markColor;
    private int markStyle;
    private int markThickness;
    private boolean rulesEnabled;
    private float ruleTop;
    private float ruleBottom;
    private boolean draggingTopRule;
    private boolean draggingBottomRule;

    private boolean selecting;
    private boolean markGesturePanning;
    private boolean multiTouchPanning;
    private float startX;
    private float startY;
    private float endX;
    private float endY;
    private float lastPanGestureX;
    private float lastPanGestureY;
    private CharBox selectionStartChar;
    private CharBox selectionEndChar;
    private int selectionAnchorLine = -1;
    private float selectionAnchorCenterY;
    private float selectionAnchorHeight;

    private boolean readingMarkerEnabled;
    private int readingMarkerColor;
    private int readingMarkerPage;
    private String readingMarkerChunk;
    private int readingMarkerChunkIndex;
    private int readingMarkerRangeStart;
    private int readingMarkerRangeEnd;
    private int readingChunkSearchOffset;
    private int readingChunkBaseOffset;
    private final ArrayList<RectF> readingMarkerRects;
    private String readingNormalizedPage;
    private final ArrayList<CharBox> readingNormalizedMapping;
    private String readingNormalizedChunk;
    private int[] readingChunkPrefix;

    private ArrayList<CharBox> charBoxes;
    private final Map<Integer, ArrayList<TextMarker>> markers;
    private final ArrayList<TextMarker> redoMarkers;
    private int workspaceColor = Color.WHITE;
    // Color de espera mientras no hay ninguna pagina cargada todavia (se
    // mezcla con el fondo oscuro de la app en vez de mostrar blanco puro).
    private static final int EMPTY_WAIT_COLOR = Color.rgb(8, 40, 58);
    private boolean alignPageTop = false;
    /** Oculta el cartel "Abrir un PDF" mientras se reabre un documento. */
    private boolean suppressEmptyLabel = false;

    /**
     * Cuando esta activo, la pagina se apoya en el borde superior en vez de
     * quedar centrada verticalmente. El espacio sobrante se junta abajo, que es
     * donde vive el banner. Solo afecta a paginas que caben enteras en pantalla:
     * si el usuario hizo zoom y la pagina es mas alta que el visor, el
     * desplazamiento sigue funcionando igual que siempre.
     */
    public void setAlignPageTop(boolean alignTop) {
        if (alignPageTop == alignTop) return;
        alignPageTop = alignTop;
        clampPan();
        invalidate();
    }

    public PdfPageView(Context context) {
        super(context);
        setBackgroundColor(workspaceColor);

        paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);

        markerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        markerPaint.setStyle(Paint.Style.FILL);

        previewPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        previewPaint.setStyle(Paint.Style.FILL);
        previewPaint.setColor(0xE6FFD400);

        rulePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        rulePaint.setStyle(Paint.Style.FILL);
        rulePaint.setColor(0xFF2F6BFF);

        blockedPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        blockedPaint.setStyle(Paint.Style.FILL);
        blockedPaint.setColor(0x33000000);

        executor = Executors.newSingleThreadExecutor();
        pendingPage = -1;
        zoom = 1.0f;
        markMode = false;
        markColor = 0xE6FFD400;
        markStyle = MARK_STYLE_UNDERLINE_FINE;
        markThickness = 1;
        rulesEnabled = true;
        ruleTop = 0.08f;
        ruleBottom = 0.92f;
        charBoxes = new ArrayList<CharBox>();
        markers = new HashMap<Integer, ArrayList<TextMarker>>();
        redoMarkers = new ArrayList<TextMarker>();
        readingMarkerRects = new ArrayList<RectF>();
        readingNormalizedMapping = new ArrayList<CharBox>();
        readingNormalizedPage = "";
        readingNormalizedChunk = "";
        readingChunkPrefix = new int[]{0};
        readingChunkSearchOffset = 0;
        readingChunkBaseOffset = -1;
        readingMarkerRangeStart = 0;
        readingMarkerRangeEnd = 0;
        readingMarkerEnabled = false;
        readingMarkerColor = 0x663B82F6;
        readingMarkerPage = -1;
        readingMarkerChunk = "";
        readingMarkerChunkIndex = -1;

        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                float oldZoom = zoom;
                zoom = clamp(zoom * detector.getScaleFactor(), 1.0f, 4.0f);
                float focusX = detector.getFocusX();
                float focusY = detector.getFocusY();
                panX = focusX - (focusX - panX) * (zoom / oldZoom);
                panY = focusY - (focusY - panY) * (zoom / oldZoom);
                clampPan();
                invalidate();
                return true;
            }

            @Override
            public void onScaleEnd(ScaleGestureDetector detector) {
                requestRender();
            }
        });

        gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (markMode) return true;

                if (zoom > 1.2f) {
                    zoom = 1.0f;
                    panX = 0f;
                    panY = 0f;
                } else {
                    zoom = 2.0f;
                    panX = e.getX() - e.getX() * zoom;
                    panY = e.getY() - e.getY() * zoom;
                    clampPan();
                }

                requestRender();
                invalidate();
                return true;
            }

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                if (markMode) return true;

                panX -= distanceX;
                panY -= distanceY;
                clampPan();
                invalidate();
                return true;
            }
        });
    }

    public void setPageChangeListener(PageChangeListener listener) {
        this.listener = listener;
    }

    public int getPageCount() {
        return pageCount;
    }


    public void setMarkMode(boolean enabled) {
        markMode = enabled;
        selecting = false;
        invalidate();
    }


    public void setMarkColor(int color) {
        markColor = color;
        previewPaint.setColor(color);
        invalidate();
    }

    public void setMarkStyle(int style) {
        markStyle = safeStyle(style);
        selecting = false;
        invalidate();
    }

    public void setMarkThickness(int level) {
        markThickness = safeThickness(level);
        invalidate();
    }

    public void setSelectionChars(ArrayList<CharBox> chars) {
        if (chars == null) charBoxes = new ArrayList<CharBox>();
        else charBoxes = chars;
        if (readingMarkerEnabled) rebuildReadingSearchCache();
        else clearReadingSearchCache();
        rebuildReadingMarkerRects();
        invalidate();
    }

    public void setRuleColor(int color) {
        rulePaint.setColor(0xFF000000 | (color & 0x00FFFFFF));
        invalidate();
    }

    public void setReadingMarkerEnabled(boolean enabled) {
        readingMarkerEnabled = enabled;
        if (!enabled) {
            readingMarkerRects.clear();
            clearReadingSearchCache();
        } else {
            rebuildReadingSearchCache();
            rebuildReadingMarkerRects();
        }
        invalidate();
    }

    public void setReadingMarkerColor(int color) {
        readingMarkerColor = (0x42000000 | (color & 0x00FFFFFF));
        invalidate();
    }

    public void updateReadingMarker(int page, String chunk, int chunkIndex, int rangeStart, int rangeEnd) {
        if (page != readingMarkerPage || chunkIndex != readingMarkerChunkIndex) {
            boolean pageChanged = page != readingMarkerPage;
            readingMarkerPage = page;
            readingMarkerChunkIndex = chunkIndex;
            readingMarkerChunk = chunk == null ? "" : chunk;
            rebuildReadingChunkCache();
            readingMarkerRangeStart = Math.max(0, rangeStart);
            readingMarkerRangeEnd = Math.max(readingMarkerRangeStart + 1, rangeEnd);
            readingChunkBaseOffset = -1;
            if (pageChanged) readingChunkSearchOffset = 0;
        } else {
            if (chunk != null && !chunk.equals(readingMarkerChunk)) {
                readingMarkerChunk = chunk;
                rebuildReadingChunkCache();
            } else if (chunk == null) {
                readingMarkerChunk = "";
                rebuildReadingChunkCache();
            }
            readingMarkerRangeStart = Math.max(0, rangeStart);
            readingMarkerRangeEnd = Math.max(readingMarkerRangeStart + 1, rangeEnd);
        }
        rebuildReadingMarkerRects();
        invalidate();
    }

    public void clearReadingMarker() {
        readingMarkerPage = -1;
        readingMarkerChunkIndex = -1;
        readingMarkerChunk = "";
        readingMarkerRangeStart = 0;
        readingMarkerRangeEnd = 0;
        readingChunkBaseOffset = -1;
        readingChunkSearchOffset = 0;
        readingMarkerRects.clear();
        readingNormalizedChunk = "";
        readingChunkPrefix = new int[0];
        invalidate();
    }

    public void setRules(boolean enabled, float top, float bottom) {
        rulesEnabled = enabled;
        ruleTop = clamp(top, 0f, 0.95f);
        ruleBottom = clamp(bottom, 0.05f, 1f);
        if (ruleBottom <= ruleTop + 0.05f) {
            ruleTop = 0.08f;
            ruleBottom = 0.92f;
        }
        invalidate();
    }




    public void undoLastHighlight() {
        ArrayList<TextMarker> list = markers.get(pageIndex);
        if (list != null && list.size() > 0) {
            TextMarker removed = list.remove(list.size() - 1);
            redoMarkers.add(removed);
            notifyHighlightsChanged();
            invalidate();
        }
    }

    public void redoLastHighlight() {
        if (redoMarkers.size() == 0) return;
        TextMarker marker = redoMarkers.remove(redoMarkers.size() - 1);
        addMarkerObject(marker, true, false);
        invalidate();
    }

    public void clearPageHighlights() {
        ArrayList<TextMarker> list = markers.get(pageIndex);
        if (list != null) {
            redoMarkers.clear();
        }
        markers.remove(pageIndex);
        notifyHighlightsChanged();
        invalidate();
    }

    public void loadHighlights(String data) {
        markers.clear();
        redoMarkers.clear();

        if (data == null || data.trim().length() == 0) {
            invalidate();
            return;
        }

        try {
            String[] items = data.split(";");
            for (String item : items) {
                String trimmed = item.trim();
                if (trimmed.length() == 0) continue;

                String[] p = trimmed.split(",");
                if (p.length < 6 || p.length > 8) continue;

                int page = Integer.parseInt(p[0]);
                int color = (int) Long.parseLong(p[1], 16);
                float left = Float.parseFloat(p[2]);
                float top = Float.parseFloat(p[3]);
                float right = Float.parseFloat(p[4]);
                float bottom = Float.parseFloat(p[5]);

                int style;
                int thickness = 1;
                if (p.length == 8) {
                    style = Integer.parseInt(p[6]);
                    thickness = Integer.parseInt(p[7]);
                } else if (p.length == 7) {
                    // Compatibilidad con V71: 0=subrayado, 1=resaltado.
                    int oldStyle = Integer.parseInt(p[6]);
                    style = oldStyle == 1 ? MARK_STYLE_HIGHLIGHT_SOFT : MARK_STYLE_UNDERLINE_FINE;
                } else {
                    style = MARK_STYLE_UNDERLINE_FINE;
                }

                addMarkerObject(new TextMarker(page, color, left, top, right, bottom, style, thickness), false, false);
            }
        } catch (Exception ignored) {
        }

        invalidate();
    }

    public String serializeHighlights() {
        StringBuilder builder = new StringBuilder();

        for (Map.Entry<Integer, ArrayList<TextMarker>> entry : markers.entrySet()) {
            ArrayList<TextMarker> list = entry.getValue();
            if (list == null) continue;

            for (TextMarker h : list) {
                builder.append(h.page).append(",");
                builder.append(Integer.toHexString(h.color)).append(",");
                builder.append(String.format(Locale.US, "%.5f", h.left)).append(",");
                builder.append(String.format(Locale.US, "%.5f", h.top)).append(",");
                builder.append(String.format(Locale.US, "%.5f", h.right)).append(",");
                builder.append(String.format(Locale.US, "%.5f", h.bottom)).append(",");
                builder.append(h.style).append(",");
                builder.append(h.thickness).append(";");
            }
        }

        return builder.toString();
    }

    public void openFileAsync(final File file, final DocumentOpenCallback callback) {
        if (file == null) {
            if (callback != null) callback.onError(new IOException("PDF invalido"));
            return;
        }

        final int openToken = ++documentOpenSerial;
        serial++;
        pendingPage = -1;
        pageCount = 0;
        pageIndex = 0;
        zoom = 1.0f;
        panX = 0f;
        panY = 0f;
        // Documento nuevo: los zooms recordados del anterior no valen.
        pageViewStates.clear();
        renderedPageIndex = -1;
        hasPendingViewState = false;
        pendingViewStatePage = -1;
        pendingZoom = 1.0f;
        pendingPanX = 0f;
        pendingPanY = 0f;
        charBoxes = new ArrayList<CharBox>();
        readingMarkerRects.clear();
        clearReadingSearchCache();
        if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
        bitmap = null;
        invalidate();

        executor.execute(new Runnable() {
            @Override
            public void run() {
                ParcelFileDescriptor newDescriptor = null;
                PdfRenderer newRenderer = null;
                try {
                    newDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
                    newRenderer = new PdfRenderer(newDescriptor);
                    final int count = newRenderer.getPageCount();
                    if (count <= 0) throw new IOException("PDF sin paginas");

                    synchronized (lock) {
                        if (openToken != documentOpenSerial) {
                            try { newRenderer.close(); } catch (Exception ignored) {}
                            try { newDescriptor.close(); } catch (Exception ignored) {}
                            return;
                        }
                        if (renderer != null) {
                            try { renderer.close(); } catch (Exception ignored) {}
                        }
                        if (descriptor != null) {
                            try { descriptor.close(); } catch (Exception ignored) {}
                        }
                        renderer = newRenderer;
                        descriptor = newDescriptor;
                        newRenderer = null;
                        newDescriptor = null;
                    }

                    post(new Runnable() {
                        @Override
                        public void run() {
                            if (openToken != documentOpenSerial) return;
                            pageCount = count;
                            pageIndex = 0;
                            zoom = 1.0f;
                            panX = 0f;
                            panY = 0f;
                            if (callback != null) callback.onOpened(count);
                        }
                    });
                } catch (final Exception error) {
                    if (newRenderer != null) {
                        try { newRenderer.close(); } catch (Exception ignored) {}
                    }
                    if (newDescriptor != null) {
                        try { newDescriptor.close(); } catch (Exception ignored) {}
                    }
                    post(new Runnable() {
                        @Override
                        public void run() {
                            if (openToken != documentOpenSerial) return;
                            if (callback != null) callback.onError(error);
                        }
                    });
                }
            }
        });
    }

    public void openFile(File file) throws IOException {
        closeDocument();
        descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
        renderer = new PdfRenderer(descriptor);
        pageCount = renderer.getPageCount();
        pageIndex = 0;
        zoom = 1.0f;
        panX = 0f;
        panY = 0f;
        pageViewStates.clear();
        renderedPageIndex = -1;
        hasPendingViewState = false;
        pendingViewStatePage = -1;
        charBoxes = new ArrayList<CharBox>();
        readingMarkerRects.clear();
        clearReadingSearchCache();
        requestRender();
    }

    /**
     * Guarda como quedo una pagina. Solo se recuerda si el usuario la dejo con
     * zoom; si esta en su tamano normal se borra cualquier recuerdo anterior,
     * asi una pagina que se dejo normal vuelve a verse completa.
     */
    private void saveViewStateForPage(int page) {
        if (page < 0) return;
        if (bitmap == null || bitmap.isRecycled()) return;
        if (zoom > 1.01f) {
            pageViewStates.put(page, new float[]{zoom, panX, panY});
        } else {
            pageViewStates.remove(page);
        }
    }

    public void showPage(int index) {
        if (renderer == null || pageCount <= 0) return;

        int safeIndex = Math.max(0, Math.min(index, pageCount - 1));

        // Si ya se esta mostrando esta misma pagina Y ya hay algo dibujado, no
        // hay nada que mover. (bitmap == null cubre el primer dibujado justo
        // despues de abrir un PDF, donde pageIndex ya es 0 pero todavia no se
        // pidio el render -- ahi SI hay que seguir, o la pagina nunca aparece.)
        if (safeIndex == pageIndex && bitmap != null && !bitmap.isRecycled()) return;

        // Antes de irse, la pagina que se esta viendo guarda como quedo. Si el
        // usuario la dejo agrandada, al volver aparece igual; si la dejo en su
        // tamano normal, no se guarda nada.
        saveViewStateForPage(renderedPageIndex);

        pageIndex = safeIndex;

        // El zoom de la pagina destino se prepara pero NO se aplica todavia: la
        // pagina vieja sigue en pantalla y cambiarselo ahora la haria saltar.
        // Se aplica justo cuando la pagina nueva aparece, en un solo pase.
        float[] saved = pageViewStates.get(safeIndex);
        pendingViewStatePage = safeIndex;
        hasPendingViewState = true;
        if (saved != null) {
            pendingZoom = saved[0];
            pendingPanX = saved[1];
            pendingPanY = saved[2];
        } else {
            pendingZoom = 1.0f;
            pendingPanX = 0f;
            pendingPanY = 0f;
        }

        charBoxes = new ArrayList<CharBox>();
        readingMarkerRects.clear();
        clearReadingSearchCache();
        requestRender();
    }

    /**
     * Cuando esta activo no se dibuja el cartel de estado vacio. Se usa durante
     * el cambio de tema, donde la vista se recrea con un PDF ya abierto.
     */
    public void setSuppressEmptyLabel(boolean suppress) {
        if (suppressEmptyLabel == suppress) return;
        suppressEmptyLabel = suppress;
        invalidate();
    }




    public void setWorkspaceColor(int color) {
        workspaceColor = color;
        setBackgroundColor(color);
        invalidate();
    }

    private void requestRender() {
        if (renderer == null || getWidth() <= 0 || getHeight() <= 0) return;

        if (renderBusy) {
            pendingPage = pageIndex;
            // Invalida el render anterior para que varios toques rápidos nunca
            // muestren una página vieja después de la última solicitada.
            serial++;
            return;
        }

        renderBusy = true;
        final int requestedPage = pageIndex;
        final int token = ++serial;
        // La imagen se pide con el zoom que va a tener la pagina destino, no
        // con el de la pagina que todavia se esta viendo. Asi aparece nitida de
        // entrada y no hace falta un segundo dibujado.
        final float renderZoom = (hasPendingViewState && pendingViewStatePage == requestedPage)
                ? pendingZoom : zoom;

        executor.execute(new Runnable() {
            @Override
            public void run() {
                Bitmap produced = null;
                PdfRenderer.Page openedPage = null;

                try {
                    synchronized (lock) {
                        if (renderer == null) return;

                        openedPage = renderer.openPage(requestedPage);
                        int viewWidth = Math.max(320, getWidth());
                        float ratio = openedPage.getHeight() / (float) openedPage.getWidth();

                        int targetWidth = Math.round(viewWidth * renderZoom * 1.5f);
                        targetWidth = Math.max(viewWidth, Math.min(targetWidth, 3200));
                        int targetHeight = Math.round(targetWidth * ratio);
                        targetHeight = Math.max(1, Math.min(targetHeight, 4800));

                        // Ahora el zoom se conserva al cambiar de pagina, asi que
                        // paginas nuevas pueden pedirse con mucho aumento. Se
                        // limita el total de puntos de la imagen para no reservar
                        // decenas de megas en cada pase y que el cambio de pagina
                        // siga siendo rapido en telefonos modestos.
                        long maxPixels = 9000000L;
                        long requested = (long) targetWidth * (long) targetHeight;
                        if (requested > maxPixels) {
                            double shrink = Math.sqrt(maxPixels / (double) requested);
                            targetWidth = Math.max(viewWidth, (int) Math.round(targetWidth * shrink));
                            targetHeight = Math.max(1, (int) Math.round(targetWidth * ratio));
                        }

                        produced = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888);
                        produced.eraseColor(Color.TRANSPARENT);
                        openedPage.render(produced, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                    }

                    applyPageBackdrop(produced);

                    final Bitmap readyBitmap = produced;
                    produced = null;

                    post(new Runnable() {
                        @Override
                        public void run() {
                            applyRenderedBitmap(readyBitmap, token, requestedPage);
                        }
                    });
                } catch (Exception ex) {
                    if (produced != null && !produced.isRecycled()) produced.recycle();

                    post(new Runnable() {
                        @Override
                        public void run() {
                            notifyRenderError();
                        }
                    });
                } finally {
                    if (openedPage != null) {
                        try {
                            openedPage.close();
                        } catch (Exception ignored) {
                        }
                    }

                    post(new Runnable() {
                        @Override
                        public void run() {
                            finishRenderQueue();
                        }
                    });
                }
            }
        });
    }

    private void applyRenderedBitmap(Bitmap readyBitmap, int token, int renderedPage) {
        if (token != serial || renderedPage != pageIndex) {
            if (readyBitmap != null && !readyBitmap.isRecycled()) readyBitmap.recycle();
            return;
        }

        Bitmap old = bitmap;
        bitmap = readyBitmap;
        if (old != null && !old.isRecycled()) old.recycle();

        renderedPageIndex = renderedPage;

        // El zoom guardado de esta pagina se aplica justo ahora, en el mismo
        // pase en que aparece la imagen nueva: no hay un instante intermedio en
        // el que se vea la pagina moverse o cambiar de tamano.
        if (hasPendingViewState && pendingViewStatePage == renderedPage) {
            zoom = pendingZoom;
            panX = pendingPanX;
            panY = pendingPanY;
            hasPendingViewState = false;
            pendingViewStatePage = -1;
        }

        clampPan();
        invalidate();

        if (listener != null) {
            listener.onPageRendered(pageIndex, pageCount);
        }
    }

    private void notifyRenderError() {
        if (listener != null) listener.onError("Error al renderizar PDF");
    }

    private void finishRenderQueue() {
        renderBusy = false;

        if (pendingPage >= 0) {
            int p = pendingPage;
            pendingPage = -1;
            pageIndex = p;
            requestRender();
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        requestRender();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (bitmap == null || bitmap.isRecycled()) {
            // Al cambiar de tema, cambiar de idioma o volver a la app despues de
            // un rato, la vista se reconstruye y el PDF se reabre un instante
            // despues. Antes se pintaba el fondo blanco del area de lectura de
            // entrada (pensado para cuando ya hay una pagina mostrandose, como
            // el papel alrededor de la hoja) incluso en este hueco de espera,
            // y con el cartel "Abrir un PDF" oculto quedaba una pantalla blanca
            // sola. Mientras no hay nada que mostrar se usa un color oscuro que
            // se mezcla con el resto de la app en vez de blanco puro.
            int waitingColor = suppressEmptyLabel ? EMPTY_WAIT_COLOR : workspaceColor;
            canvas.drawColor(waitingColor);
            if (suppressEmptyLabel) return;
            Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            textPaint.setColor(workspaceColor == Color.WHITE ? Color.DKGRAY : Color.rgb(203, 213, 225));
            textPaint.setTextSize(42f);
            textPaint.setTextAlign(Paint.Align.CENTER);
            String emptyLabel = UiStrings.translate(UiStrings.currentLanguage(getContext()), "Abrir un PDF");
            canvas.drawText(emptyLabel, getWidth() / 2f, getHeight() / 2f, textPaint);
            return;
        }

        canvas.drawColor(workspaceColor);
        RectF pageRect = getCurrentPageRect();
        canvas.drawBitmap(bitmap, null, pageRect, paint);
        drawReadingMarker(canvas, pageRect);
        drawSavedMarkers(canvas, pageRect);

        if (selecting) {
            drawSelectionPreview(canvas, pageRect);
        }

        drawReadingRules(canvas, pageRect);
    }


    private void drawReadingMarker(Canvas canvas, RectF pageRect) {
        if (!readingMarkerEnabled || readingMarkerPage != pageIndex || readingMarkerRects.isEmpty()) return;
        markerPaint.setStyle(Paint.Style.FILL);
        markerPaint.setColor(readingMarkerColor);
        for (RectF normalized : readingMarkerRects) {
            RectF actual = new RectF(
                    pageRect.left + normalized.left * pageRect.width(),
                    pageRect.top + normalized.top * pageRect.height(),
                    pageRect.left + normalized.right * pageRect.width(),
                    pageRect.top + normalized.bottom * pageRect.height());
            float radius = Math.max(2f, actual.height() * 0.12f);
            canvas.drawRoundRect(actual, radius, radius, markerPaint);
        }
    }

    private void rebuildReadingSearchCache() {
        readingNormalizedMapping.clear();
        StringBuilder page = new StringBuilder();
        if (charBoxes != null) {
            for (CharBox box : charBoxes) {
                if (box == null || box.page != pageIndex || box.text == null) continue;
                String normalized = normalizeLight(box.text);
                for (int i = 0; i < normalized.length(); i++) {
                    page.append(normalized.charAt(i));
                    readingNormalizedMapping.add(box);
                }
            }
        }
        readingNormalizedPage = page.toString();
        readingChunkBaseOffset = -1;
    }

    private void clearReadingSearchCache() {
        readingNormalizedPage = "";
        readingNormalizedMapping.clear();
        readingChunkBaseOffset = -1;
    }

    private void rebuildReadingChunkCache() {
        String source = readingMarkerChunk == null ? "" : readingMarkerChunk;
        StringBuilder normalized = new StringBuilder();
        readingChunkPrefix = new int[source.length() + 1];
        int count = 0;
        for (int i = 0; i < source.length(); i++) {
            String part = normalizeLight(String.valueOf(source.charAt(i)));
            normalized.append(part);
            count += part.length();
            readingChunkPrefix[i + 1] = count;
        }
        readingNormalizedChunk = normalized.toString();
    }

    private void rebuildReadingMarkerRects() {
        readingMarkerRects.clear();
        if (!readingMarkerEnabled || readingMarkerPage != pageIndex || charBoxes == null || charBoxes.isEmpty()) return;
        if (readingMarkerChunk == null || readingMarkerChunk.trim().length() == 0) return;
        if (readingNormalizedPage.length() == 0 || readingNormalizedMapping.isEmpty()) rebuildReadingSearchCache();
        if (readingNormalizedChunk.length() == 0) rebuildReadingChunkCache();
        if (readingNormalizedPage.length() == 0 || readingNormalizedMapping.isEmpty() || readingNormalizedChunk.length() == 0) return;

        if (readingChunkBaseOffset < 0) {
            String key = readingNormalizedChunk.substring(0, Math.min(28, readingNormalizedChunk.length()));
            int searchFrom = Math.max(0, Math.min(readingChunkSearchOffset, readingNormalizedPage.length()));
            int found = readingNormalizedPage.indexOf(key, searchFrom);
            if (found < 0) found = readingNormalizedPage.indexOf(key);
            readingChunkBaseOffset = found < 0 ? 0 : found;
            readingChunkSearchOffset = Math.max(readingChunkSearchOffset,
                    readingChunkBaseOffset + Math.max(1, readingNormalizedChunk.length() / 2));
        }

        int maxPrefix = readingChunkPrefix.length - 1;
        int startOriginal = Math.max(0, Math.min(readingMarkerRangeStart, maxPrefix));
        int endOriginal = Math.max(startOriginal, Math.min(readingMarkerRangeEnd, maxPrefix));
        int localStart = readingChunkPrefix[startOriginal];
        int localEnd = readingChunkPrefix[endOriginal];

        int absolute = Math.max(0, Math.min(readingNormalizedMapping.size() - 1, readingChunkBaseOffset + localStart));
        int absoluteEnd = Math.max(absolute, Math.min(readingNormalizedMapping.size() - 1,
                readingChunkBaseOffset + Math.max(localStart + 1, localEnd) - 1));
        CharBox first = readingNormalizedMapping.get(absolute);
        CharBox last = readingNormalizedMapping.get(absoluteEnd);
        int targetLine = first.line;
        if (last.line != targetLine && localEnd - localStart > 1) targetLine = last.line;

        float left = 1f;
        float top = 1f;
        float right = 0f;
        float bottom = 0f;
        boolean foundLine = false;
        for (CharBox box : charBoxes) {
            if (box != null && box.page == pageIndex && box.line == targetLine) {
                left = Math.min(left, box.left);
                top = Math.min(top, box.top);
                right = Math.max(right, box.right);
                bottom = Math.max(bottom, box.bottom);
                foundLine = true;
            }
        }
        if (foundLine) {
            // Recuadro mas holgado: antes quedaba pegado al texto y el
            // seguimiento casi no se notaba mientras se escuchaba.
            float height = Math.max(0.006f, bottom - top);
            float padX = Math.max(0.006f, height * 0.30f);
            float padY = Math.max(0.004f, height * 0.26f);
            readingMarkerRects.add(new RectF(clamp(left - padX, 0f, 1f), clamp(top - padY, 0f, 1f),
                    clamp(right + padX, 0f, 1f), clamp(bottom + padY, 0f, 1f)));
        }
    }

    private String normalizeLight(String value) {
        if (value == null || value.length() == 0) return "";
        StringBuilder out = new StringBuilder(value.length());
        for (int i = 0; i < value.length(); i++) {
            char c = Character.toLowerCase(value.charAt(i));
            switch (c) {
                case 'á': case 'à': case 'ä': case 'â': c = 'a'; break;
                case 'é': case 'è': case 'ë': case 'ê': c = 'e'; break;
                case 'í': case 'ì': case 'ï': case 'î': c = 'i'; break;
                case 'ó': case 'ò': case 'ö': case 'ô': c = 'o'; break;
                case 'ú': case 'ù': case 'ü': case 'û': c = 'u'; break;
                default: break;
            }
            if (Character.isLetterOrDigit(c)) out.append(c);
        }
        return out.toString();
    }

    private void drawSavedMarkers(Canvas canvas, RectF pageRect) {
        drawMarkersForPage(canvas, pageRect, pageIndex);
    }

    private void drawMarkersForPage(Canvas canvas, RectF pageRect, int targetPage) {
        ArrayList<TextMarker> list = markers.get(targetPage);
        if (list == null) return;

        for (TextMarker h : list) {
            drawMarkerRect(canvas, pageRect, h.left, h.top, h.right, h.bottom, h.color, h.style, h.thickness);
        }
    }

    private void drawSelectionPreview(Canvas canvas, RectF pageRect) {
        ArrayList<TextMarker> preview = buildMarkersFromSelection();
        for (TextMarker h : preview) {
            drawMarkerRect(canvas, pageRect, h.left, h.top, h.right, h.bottom, markColor, markStyle, markThickness);
        }
    }

    private void drawMarkerRect(Canvas canvas, RectF pageRect, float left, float top, float right, float bottom, int color, int style, int thicknessLevel) {
        markerPaint.setColor(color);
        markerPaint.setStyle(Paint.Style.FILL);

        float x1 = pageRect.left + left * pageRect.width();
        float x2 = pageRect.left + right * pageRect.width();
        float yTop = pageRect.top + top * pageRect.height();
        float yBottom = pageRect.top + bottom * pageRect.height();
        float textHeight = Math.max(1f, yBottom - yTop);
        float thicknessMultiplier = thicknessLevel == 0 ? 0.72f : (thicknessLevel == 2 ? 1.65f : 1.0f);
        float lineThickness = Math.max(2.0f, pageRect.height() * 0.0022f) * thicknessMultiplier;

        if (style == MARK_STYLE_HIGHLIGHT_SOFT || style == MARK_STYLE_HIGHLIGHT_INTENSE) {
            int rgb = color & 0x00FFFFFF;
            int alpha = style == MARK_STYLE_HIGHLIGHT_INTENSE ? 0x82 : 0x4A;
            markerPaint.setColor((alpha << 24) | rgb);
            float paddingY = Math.max(0.5f, textHeight * 0.03f);
            RectF highlight = new RectF(
                    Math.max(pageRect.left, x1),
                    Math.max(pageRect.top, yTop - paddingY),
                    Math.min(pageRect.right, x2),
                    Math.min(pageRect.bottom, yBottom + paddingY)
            );
            float radius = Math.max(1.5f, textHeight * 0.10f);
            canvas.drawRoundRect(highlight, radius, radius, markerPaint);
            markerPaint.setColor(color);
            return;
        }


        float baseY = yBottom + lineThickness * 1.1f;

        if (style == MARK_STYLE_UNDERLINE_DOUBLE) {
            RectF first = new RectF(x1, baseY, x2, baseY + lineThickness);
            RectF second = new RectF(x1, baseY + lineThickness * 2.0f, x2, baseY + lineThickness * 3.0f);
            canvas.drawRoundRect(first, lineThickness, lineThickness, markerPaint);
            canvas.drawRoundRect(second, lineThickness, lineThickness, markerPaint);
            return;
        }

        if (style == MARK_STYLE_UNDERLINE_WAVY) {
            markerPaint.setStyle(Paint.Style.STROKE);
            markerPaint.setStrokeWidth(lineThickness);
            markerPaint.setStrokeCap(Paint.Cap.ROUND);
            Path path = new Path();
            float amplitude = Math.max(2f, lineThickness * 1.8f);
            float wavelength = Math.max(10f, textHeight * 0.55f);
            path.moveTo(x1, baseY);
            float x = x1;
            boolean up = true;
            while (x < x2) {
                float next = Math.min(x + wavelength / 2f, x2);
                float mid = (x + next) / 2f;
                path.quadTo(mid, baseY + (up ? -amplitude : amplitude), next, baseY);
                up = !up;
                x = next;
            }
            canvas.drawPath(path, markerPaint);
            markerPaint.setStyle(Paint.Style.FILL);
            return;
        }

        if (style == MARK_STYLE_UNDERLINE_DOTTED) {
            float radius = Math.max(1.2f, lineThickness * (thicknessLevel == 0 ? 0.52f : (thicknessLevel == 2 ? 0.78f : 0.64f)));
            float step = Math.max(radius * 2.8f, textHeight * 0.11f);
            float start = x1 + radius;
            float phase = (start - pageRect.left) % step;
            if (phase < 0f) phase += step;
            if (phase > 0.001f) start += (step - phase);
            if (start > x2 - radius) start = (x1 + x2) * 0.5f;
            float centerY = baseY + radius * 0.85f;
            for (float x = start; x <= x2 - radius * 0.15f; x += step) {
                canvas.drawCircle(x, centerY, radius, markerPaint);
            }
            return;
        }

        RectF line = new RectF(x1, baseY, x2, baseY + lineThickness);
        canvas.drawRoundRect(line, lineThickness, lineThickness, markerPaint);
    }

    private void drawReadingRules(Canvas canvas, RectF pageRect) {
        if (!rulesEnabled) return;

        float topY = pageRect.top + ruleTop * pageRect.height();
        float bottomY = pageRect.top + ruleBottom * pageRect.height();
        float h = Math.max(4f, 4f * zoom);

        canvas.drawRect(pageRect.left, pageRect.top, pageRect.right, topY, blockedPaint);
        canvas.drawRect(pageRect.left, bottomY, pageRect.right, pageRect.bottom, blockedPaint);

        RectF topLine = new RectF(pageRect.left, topY - h / 2f, pageRect.right, topY + h / 2f);
        RectF bottomLine = new RectF(pageRect.left, bottomY - h / 2f, pageRect.right, bottomY + h / 2f);

        canvas.drawRoundRect(topLine, h, h, rulePaint);
        canvas.drawRoundRect(bottomLine, h, h, rulePaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();

        if (markMode && (event.getPointerCount() >= 2 || multiTouchPanning)) {
            if (action == MotionEvent.ACTION_POINTER_DOWN || action == MotionEvent.ACTION_DOWN) {
                multiTouchPanning = true;
                selecting = false;
                markGesturePanning = false;
                selectionStartChar = null;
                selectionEndChar = null;
                selectionAnchorLine = -1;
                lastPanGestureX = averagePointerX(event);
                lastPanGestureY = averagePointerY(event);
            } else if (action == MotionEvent.ACTION_MOVE && event.getPointerCount() >= 2) {
                float focusX = averagePointerX(event);
                float focusY = averagePointerY(event);
                panX += focusX - lastPanGestureX;
                panY += focusY - lastPanGestureY;
                lastPanGestureX = focusX;
                lastPanGestureY = focusY;
                clampPan();
            } else if (action == MotionEvent.ACTION_POINTER_UP || action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                if (event.getPointerCount() <= 2) multiTouchPanning = false;
            }
            scaleDetector.onTouchEvent(event);
            invalidate();
            return true;
        }

        if (markMode && event.getPointerCount() == 1) {
            handleTextSelectionTouch(event);
            return true;
        }

        if (rulesEnabled && event.getPointerCount() == 1 && handleRuleTouch(event)) {
            return true;
        }

        scaleDetector.onTouchEvent(event);
        if (!scaleDetector.isInProgress()) gestureDetector.onTouchEvent(event);

        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            clampPan();
            invalidate();
        }

        return true;
    }

    private float averagePointerX(MotionEvent event) {
        float total = 0f;
        int count = Math.max(1, event.getPointerCount());
        for (int i = 0; i < count; i++) total += event.getX(i);
        return total / count;
    }

    private float averagePointerY(MotionEvent event) {
        float total = 0f;
        int count = Math.max(1, event.getPointerCount());
        for (int i = 0; i < count; i++) total += event.getY(i);
        return total / count;
    }

    private void handleTextSelectionTouch(MotionEvent event) {
        // Sin esta comprobacion, tocar la pagina antes de que termine de
        // dibujarse (o justo despues de cerrar el documento) reventaba la app:
        // getCurrentPageRect mide sobre el bitmap, que en ese instante es nulo.
        if (bitmap == null || bitmap.isRecycled()) return;
        int action = event.getActionMasked();
        RectF pageRect = getCurrentPageRect();

        if (pageRect.width() <= 0f || pageRect.height() <= 0f) return;

        if (action == MotionEvent.ACTION_DOWN) {
            startX = event.getX();
            startY = event.getY();
            endX = startX;
            endY = startY;
            lastPanGestureX = startX;
            lastPanGestureY = startY;

            float nx = clamp((startX - pageRect.left) / pageRect.width(), 0f, 1f);
            float ny = clamp((startY - pageRect.top) / pageRect.height(), 0f, 1f);
            selectionStartChar = findStartCharForSelection(nx, ny);
            selectionEndChar = selectionStartChar;
            selecting = selectionStartChar != null;
            selectionAnchorLine = selecting ? selectionStartChar.line : -1;
            selectionAnchorCenterY = selecting ? selectionStartChar.centerY() : ny;
            selectionAnchorHeight = selecting
                    ? Math.max(0.004f, selectionStartChar.bottom - selectionStartChar.top)
                    : 0.012f;

            markGesturePanning = false;
            invalidate();
            return;
        }

        if (action == MotionEvent.ACTION_MOVE) {
            endX = event.getX();
            endY = event.getY();
            float nx = clamp((endX - pageRect.left) / pageRect.width(), 0f, 1f);
            float ny = clamp((endY - pageRect.top) / pageRect.height(), 0f, 1f);

            // If the initial touch landed just outside a letter, acquire the first
            // real line as soon as the finger enters it. This avoids ignored drags.
            if (!selecting || selectionStartChar == null) {
                CharBox acquired = findStartCharForSelection(nx, ny);
                if (acquired != null) {
                    selectionStartChar = acquired;
                    selectionEndChar = acquired;
                    selecting = true;
                    selectionAnchorLine = acquired.line;
                    selectionAnchorCenterY = acquired.centerY();
                    selectionAnchorHeight = Math.max(0.004f, acquired.bottom - acquired.top);
                }
            }

            if (selecting && selectionStartChar != null) {
                boolean allowAnotherLine = Math.abs(ny - selectionAnchorCenterY)
                        > Math.max(0.018f, selectionAnchorHeight * 1.75f);
                CharBox candidate = findSelectionChar(nx, ny, allowAnotherLine);
                if (candidate != null) selectionEndChar = candidate;
            }
            invalidate();
            return;
        }

        if (action == MotionEvent.ACTION_UP) {
            endX = event.getX();
            endY = event.getY();
            if (selecting && selectionStartChar != null && selectionEndChar != null) {
                ArrayList<TextMarker> newMarkers = buildMarkersFromSelection();
                if (newMarkers.size() > 0) {
                    redoMarkers.clear();
                    for (TextMarker marker : newMarkers) addMarkerObject(marker, false, false);
                    notifyHighlightsChanged();
                }
            }
            resetSelectionGesture();
            clampPan();
            invalidate();
        } else if (action == MotionEvent.ACTION_CANCEL) {
            resetSelectionGesture();
            invalidate();
        }
    }

    private void resetSelectionGesture() {
        selecting = false;
        markGesturePanning = false;
        selectionStartChar = null;
        selectionEndChar = null;
        selectionAnchorLine = -1;
        selectionAnchorCenterY = 0f;
        selectionAnchorHeight = 0f;
    }

    private CharBox findSelectionChar(float x, float y, boolean allowAnotherLine) {
        if (selectionStartChar == null) return null;

        // While the finger remains near the starting row, lock the selection to
        // that row and follow only the horizontal position. Small vertical drift
        // must not make the gesture fail or jump to another row.
        if (!allowAnotherLine) {
            CharBox sameLine = findCharOnLine(selectionAnchorLine, x, selectionAnchorCenterY, false);
            return sameLine == null ? selectionEndChar : sameLine;
        }

        int bestLine = findNearestTextLine(y, Math.max(0.008f, selectionAnchorHeight * 0.58f));
        if (bestLine < 0) return selectionEndChar;

        CharBox found = findCharOnLine(bestLine, x, y, false);
        return found == null ? selectionEndChar : found;
    }

    private CharBox findStartCharForSelection(float x, float y) {
        if (charBoxes == null || charBoxes.isEmpty()) return null;

        int line = findNearestTextLine(y, -1f);
        if (line < 0) return null;
        return findCharOnLine(line, x, y, true);
    }

    private int findNearestTextLine(float y, float explicitTolerance) {
        int bestLine = -1;
        float bestDistance = Float.MAX_VALUE;
        Map<Integer, float[]> lineBounds = new HashMap<Integer, float[]>();

        for (CharBox c : charBoxes) {
            if (c == null || c.page != pageIndex || c.text == null || c.text.trim().length() == 0) continue;
            float[] bounds = lineBounds.get(c.line);
            if (bounds == null) {
                bounds = new float[]{c.top, c.bottom, Math.max(0.004f, c.bottom - c.top), 1f};
                lineBounds.put(c.line, bounds);
            } else {
                bounds[0] = Math.min(bounds[0], c.top);
                bounds[1] = Math.max(bounds[1], c.bottom);
                bounds[2] += Math.max(0.004f, c.bottom - c.top);
                bounds[3] += 1f;
            }
        }

        for (Map.Entry<Integer, float[]> entry : lineBounds.entrySet()) {
            float[] bounds = entry.getValue();
            float averageHeight = bounds[2] / Math.max(1f, bounds[3]);
            float distance;
            if (y < bounds[0]) distance = bounds[0] - y;
            else if (y > bounds[1]) distance = y - bounds[1];
            else distance = 0f;

            float tolerance = explicitTolerance >= 0f
                    ? explicitTolerance
                    : Math.max(0.0065f, averageHeight * 0.48f);
            if (distance <= tolerance && distance < bestDistance) {
                bestDistance = distance;
                bestLine = entry.getKey();
            }
        }
        return bestLine;
    }

    private CharBox findCharOnLine(int line, float x, float y, boolean strictVertical) {
        CharBox best = null;
        float minLeft = 1f;
        float maxRight = 0f;
        float minTop = 1f;
        float maxBottom = 0f;
        float averageHeight = 0f;
        int count = 0;

        for (CharBox c : charBoxes) {
            if (c == null || c.page != pageIndex || c.line != line
                    || c.text == null || c.text.trim().length() == 0) continue;
            minLeft = Math.min(minLeft, c.left);
            maxRight = Math.max(maxRight, c.right);
            minTop = Math.min(minTop, c.top);
            maxBottom = Math.max(maxBottom, c.bottom);
            averageHeight += Math.max(0.004f, c.bottom - c.top);
            count++;
        }
        if (count == 0) return null;
        averageHeight /= count;
        float verticalPad = strictVertical
                ? Math.max(0.005f, averageHeight * 0.42f)
                : Math.max(0.008f, averageHeight * 0.70f);
        if (y < minTop - verticalPad || y > maxBottom + verticalPad) return null;
        float horizontalPad = strictVertical
                ? Math.max(0.016f, averageHeight * 1.55f)
                : Math.max(0.020f, averageHeight * 1.85f);
        if (x < minLeft - horizontalPad || x > maxRight + horizontalPad) return null;

        float bestDistance = Float.MAX_VALUE;
        for (CharBox c : charBoxes) {
            if (c == null || c.page != pageIndex || c.line != line
                    || c.text == null || c.text.trim().length() == 0) continue;
            float distance;
            if (x < c.left) distance = c.left - x;
            else if (x > c.right) distance = x - c.right;
            else distance = 0f;
            if (distance < bestDistance) {
                bestDistance = distance;
                best = c;
            }
        }
        return best;
    }

    private ArrayList<TextMarker> buildMarkersFromSelection() {
        ArrayList<TextMarker> result = new ArrayList<TextMarker>();
        if (bitmap == null || charBoxes == null || charBoxes.size() == 0) return result;

        CharBox startChar = selectionStartChar;
        CharBox endChar = selectionEndChar;
        if (startChar == null || endChar == null) return result;

        int a = Math.min(startChar.index, endChar.index);
        int b = Math.max(startChar.index, endChar.index);

        ArrayList<CharBox> selected = new ArrayList<CharBox>();
        for (CharBox c : charBoxes) {
            if (c.page == pageIndex && c.index >= a && c.index <= b) {
                selected.add(c);
            }
        }

        if (selected.size() == 0) return result;

        int currentLine = -999;
        float left = 1f;
        float top = 1f;
        float right = 0f;
        float bottom = 0f;
        boolean hasSegment = false;

        for (int i = 0; i < selected.size(); i++) {
            CharBox c = selected.get(i);
            boolean visible = c.text != null && c.text.trim().length() > 0;

            if (!visible) {
                if (hasSegment) {
                    addSegment(result, left, top, right, bottom);
                    hasSegment = false;
                }
                continue;
            }

            float charHeight = Math.max(0.0001f, c.bottom - c.top);
            boolean sameLine = hasSegment && c.line == currentLine;
            boolean gapIsSmall = sameLine && (c.left - right) <= Math.max(0.005f, charHeight * 0.80f);

            if (!hasSegment) {
                currentLine = c.line;
                left = c.left;
                top = c.top;
                right = c.right;
                bottom = c.bottom;
                hasSegment = true;
            } else if (sameLine && gapIsSmall) {
                left = Math.min(left, c.left);
                top = Math.min(top, c.top);
                right = Math.max(right, c.right);
                bottom = Math.max(bottom, c.bottom);
            } else {
                addSegment(result, left, top, right, bottom);
                currentLine = c.line;
                left = c.left;
                top = c.top;
                right = c.right;
                bottom = c.bottom;
                hasSegment = true;
            }
        }

        if (hasSegment) addSegment(result, left, top, right, bottom);
        return result;
    }

    private void addSegment(ArrayList<TextMarker> result, float left, float top, float right, float bottom) {
        if (right <= left || bottom <= top) return;

        float height = bottom - top;
        float adjustedTop = clamp(top + height * 0.05f, 0f, 1f);
        float adjustedBottom = clamp(bottom - height * 0.02f, 0f, 1f);

        result.add(new TextMarker(pageIndex, markColor, left, adjustedTop, right, adjustedBottom, markStyle, markThickness));
    }


    private boolean handleRuleTouch(MotionEvent event) {
        if (bitmap == null) return false;

        RectF pageRect = getCurrentPageRect();
        if (!pageRect.contains(event.getX(), event.getY())) return false;

        float topY = pageRect.top + ruleTop * pageRect.height();
        float bottomY = pageRect.top + ruleBottom * pageRect.height();
        float threshold = Math.max(24f, 18f * zoom);
        int action = event.getActionMasked();

        if (action == MotionEvent.ACTION_DOWN) {
            if (Math.abs(event.getY() - topY) <= threshold) {
                draggingTopRule = true;
                draggingBottomRule = false;
                return true;
            }

            if (Math.abs(event.getY() - bottomY) <= threshold) {
                draggingTopRule = false;
                draggingBottomRule = true;
                return true;
            }

            return false;
        }

        if (action == MotionEvent.ACTION_MOVE && (draggingTopRule || draggingBottomRule)) {
            float ratio = clamp((event.getY() - pageRect.top) / pageRect.height(), 0f, 1f);

            if (draggingTopRule) {
                ruleTop = clamp(ratio, 0f, ruleBottom - 0.08f);
            } else {
                ruleBottom = clamp(ratio, ruleTop + 0.08f, 1f);
            }

            invalidate();
            return true;
        }

        if ((action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) && (draggingTopRule || draggingBottomRule)) {
            draggingTopRule = false;
            draggingBottomRule = false;
            notifyRulesChanged();
            invalidate();
            return true;
        }

        return draggingTopRule || draggingBottomRule;
    }

    private void notifyRulesChanged() {
        if (listener != null) {
            listener.onRulesChanged(rulesEnabled, ruleTop, ruleBottom);
        }
    }

    private void addMarkerObject(TextMarker marker, boolean notify, boolean clearRedo) {
        ArrayList<TextMarker> list = markers.get(marker.page);

        if (list == null) {
            list = new ArrayList<TextMarker>();
            markers.put(marker.page, list);
        }

        TextMarker merged = new TextMarker(marker.page, marker.color, marker.left, marker.top,
                marker.right, marker.bottom, marker.style, marker.thickness);
        removeOverlappingMarkers(list, merged);
        list.add(merged);

        if (clearRedo) {
            redoMarkers.clear();
        }

        if (notify) {
            notifyHighlightsChanged();
        }
    }

    private void removeOverlappingMarkers(ArrayList<TextMarker> list, TextMarker incoming) {
        if (list == null || incoming == null) return;

        for (int i = list.size() - 1; i >= 0; i--) {
            TextMarker existing = list.get(i);
            if (existing == null) continue;
            if (canMergeMarkers(existing, incoming)) {
                incoming.left = Math.min(incoming.left, existing.left);
                incoming.top = Math.min(incoming.top, existing.top);
                incoming.right = Math.max(incoming.right, existing.right);
                incoming.bottom = Math.max(incoming.bottom, existing.bottom);
                list.remove(i);
            } else if (sameMarkerFamily(existing.style, incoming.style) && overlapEnough(existing, incoming)) {
                list.remove(i);
            }
        }
    }

    private boolean canMergeMarkers(TextMarker existing, TextMarker incoming) {
        if (existing.page != incoming.page) return false;
        if (existing.style != incoming.style) return false;
        if (existing.thickness != incoming.thickness) return false;
        if (existing.color != incoming.color) return false;

        float existingCenter = (existing.top + existing.bottom) * 0.5f;
        float incomingCenter = (incoming.top + incoming.bottom) * 0.5f;
        float avgHeight = Math.max(existing.bottom - existing.top, incoming.bottom - incoming.top);
        float verticalDistance = Math.abs(existingCenter - incomingCenter);
        if (verticalDistance > Math.max(0.016f, avgHeight * 0.80f)) return false;

        float horizontalGap;
        if (incoming.left > existing.right) horizontalGap = incoming.left - existing.right;
        else if (existing.left > incoming.right) horizontalGap = existing.left - incoming.right;
        else horizontalGap = 0f;

        return horizontalGap <= Math.max(0.010f, avgHeight * 1.35f);
    }

    private boolean sameMarkerFamily(int a, int b) {
        boolean underlineA = a >= MARK_STYLE_UNDERLINE_FINE && a <= MARK_STYLE_UNDERLINE_DOTTED;
        boolean underlineB = b >= MARK_STYLE_UNDERLINE_FINE && b <= MARK_STYLE_UNDERLINE_DOTTED;
        boolean highlightA = a == MARK_STYLE_HIGHLIGHT_SOFT || a == MARK_STYLE_HIGHLIGHT_INTENSE;
        boolean highlightB = b == MARK_STYLE_HIGHLIGHT_SOFT || b == MARK_STYLE_HIGHLIGHT_INTENSE;
        if (underlineA && underlineB) return true;
        if (highlightA && highlightB) return true;
        return a == b;
    }

    private boolean overlapEnough(TextMarker a, TextMarker b) {
        float left = Math.max(a.left, b.left);
        float top = Math.max(a.top, b.top);
        float right = Math.min(a.right, b.right);
        float bottom = Math.min(a.bottom, b.bottom);
        if (right <= left || bottom <= top) return false;

        float intersection = (right - left) * (bottom - top);
        float areaA = Math.max(0.00001f, (a.right - a.left) * (a.bottom - a.top));
        float areaB = Math.max(0.00001f, (b.right - b.left) * (b.bottom - b.top));
        float ratio = intersection / Math.min(areaA, areaB);

        float verticalCenterA = (a.top + a.bottom) * 0.5f;
        float verticalCenterB = (b.top + b.bottom) * 0.5f;
        float verticalDistance = Math.abs(verticalCenterA - verticalCenterB);

        return ratio >= 0.55f && verticalDistance <= Math.max(0.018f, Math.max(a.bottom - a.top, b.bottom - b.top) * 0.75f);
    }

    private void notifyHighlightsChanged() {
        if (listener != null) {
            listener.onHighlightsChanged(serializeHighlights());
        }
    }

    private RectF getCurrentPageRect() {
        // Segunda red: cualquier camino que llegue aqui sin pagina dibujada
        // recibe un rectangulo vacio en vez de reventar.
        if (bitmap == null || bitmap.isRecycled()) return new RectF(0f, 0f, 0f, 0f);
        float baseScale = getWidth() / (float) Math.max(1, bitmap.getWidth());
        float displayWidth = bitmap.getWidth() * baseScale * zoom;
        float displayHeight = bitmap.getHeight() * baseScale * zoom;
        if (Math.abs(displayWidth - getWidth()) <= 1.5f) {
            displayWidth = getWidth();
            panX = 0f;
        }

        if (displayWidth <= getWidth()) {
            panX = (getWidth() - displayWidth) / 2f;
        }
        if (displayHeight <= getHeight()) {
            panY = alignPageTop ? 0f : (getHeight() - displayHeight) / 2f;
        }

        return new RectF(panX, panY, panX + displayWidth, panY + displayHeight);
    }

    private void clampPan() {
        if (bitmap == null) return;

        float baseScale = getWidth() / (float) Math.max(1, bitmap.getWidth());
        float displayWidth = bitmap.getWidth() * baseScale * zoom;
        float displayHeight = bitmap.getHeight() * baseScale * zoom;
        if (Math.abs(displayWidth - getWidth()) <= 1.5f) {
            displayWidth = getWidth();
            panX = 0f;
        }

        if (displayWidth <= getWidth()) {
            panX = (getWidth() - displayWidth) / 2f;
        } else {
            panX = clamp(panX, getWidth() - displayWidth, 0f);
        }

        if (displayHeight <= getHeight()) {
            panY = alignPageTop ? 0f : (getHeight() - displayHeight) / 2f;
        } else {
            panY = clamp(panY, getHeight() - displayHeight, 0f);
        }
    }

    private static int safeStyle(int style) {
        if (style == MARK_STYLE_TEXT_BOX) return MARK_STYLE_UNDERLINE_FINE;
        if (style < MARK_STYLE_UNDERLINE_FINE || style > MARK_STYLE_HIGHLIGHT_INTENSE) {
            return MARK_STYLE_UNDERLINE_FINE;
        }
        return style;
    }

    private static int safeThickness(int thickness) {
        if (thickness < 0 || thickness > 2) return 1;
        return thickness;
    }

    private float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }



    /**
     * La hoja se dibuja sobre un lienzo transparente. Despues se decide si hace
     * falta ponerle una hoja blanca detras:
     *
     * - Si la pagina es una ilustracion suelta que no llena la hoja (tipico de
     *   manga o laminas), no se pinta nada: lo que sobra queda transparente y se
     *   ve el fondo de la app en vez de una plancha blanca.
     * - En cualquier otro caso (texto, paginas mixtas, dudas) se pinta la hoja
     *   blanca completa exactamente como siempre, para que el texto negro nunca
     *   quede ilegible sobre el fondo oscuro.
     */
    private void applyPageBackdrop(Bitmap page) {
        if (page == null || page.isRecycled()) return;
        boolean keepTransparent = false;
        try {
            keepTransparent = pageIsStandaloneArtwork(page);
        } catch (Throwable ignored) {
            keepTransparent = false;
        }
        if (keepTransparent) return;
        try {
            Canvas canvas = new Canvas(page);
            Paint backdrop = new Paint();
            backdrop.setColor(Color.WHITE);
            backdrop.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OVER));
            canvas.drawRect(0f, 0f, page.getWidth(), page.getHeight(), backdrop);
        } catch (Throwable ignored) {
        }
    }

    /**
     * Analiza una copia diminuta de la pagina para saber si es "solo un dibujo".
     * Se considera que lo es cuando existe un bloque solido grande (la imagen) y
     * fuera de ese bloque practicamente no hay nada dibujado. Ante la menor duda
     * devuelve false, que es el camino seguro (hoja blanca de siempre).
     */
    private boolean pageIsStandaloneArtwork(Bitmap page) {
        Bitmap small = null;
        try {
            int width = page.getWidth();
            int height = page.getHeight();
            if (width <= 0 || height <= 0) return false;

            int gridWidth = 120;
            int gridHeight = Math.max(1, Math.round(gridWidth * (height / (float) width)));
            if (gridHeight > 320) {
                gridHeight = 320;
                gridWidth = Math.max(1, Math.round(gridHeight * (width / (float) height)));
            }
            if (gridWidth < 8 || gridHeight < 8) return false;

            small = Bitmap.createScaledBitmap(page, gridWidth, gridHeight, true);
            if (small == null) return false;

            int[] pixels = new int[gridWidth * gridHeight];
            small.getPixels(pixels, 0, gridWidth, 0, 0, gridWidth, gridHeight);

            int totalCells = gridWidth * gridHeight;
            int solidCells = 0;
            int minX = gridWidth;
            int minY = gridHeight;
            int maxX = -1;
            int maxY = -1;

            for (int y = 0; y < gridHeight; y++) {
                int rowStart = y * gridWidth;
                for (int x = 0; x < gridWidth; x++) {
                    int alpha = (pixels[rowStart + x] >>> 24) & 0xFF;
                    if (alpha >= 200) {
                        solidCells++;
                        if (x < minX) minX = x;
                        if (x > maxX) maxX = x;
                        if (y < minY) minY = y;
                        if (y > maxY) maxY = y;
                    }
                }
            }

            // Sin un bloque solido suficientemente grande no hay ilustracion que
            // justifique quitar la hoja blanca.
            if (maxX < 0 || solidCells < totalCells * 0.06f) return false;

            // Se deja un cuadro de margen alrededor del bloque para no contar los
            // bordes suavizados de la propia imagen como si fueran otra cosa.
            int boxLeft = Math.max(0, minX - 1);
            int boxTop = Math.max(0, minY - 1);
            int boxRight = Math.min(gridWidth - 1, maxX + 1);
            int boxBottom = Math.min(gridHeight - 1, maxY + 1);

            // Comprobaciones anti-error (v143). Antes solo se miraba DONDE hay
            // algo dibujado, no COMO esta dibujado. Una pagina de texto tambien
            // forma un bloque rectangular grande (el area de lectura) con los
            // margenes vacios alrededor, asi que pasaba por ilustracion, se le
            // quitaba la hoja blanca y quedaba oscura e ilegible.
            //
            // Se agregan dos senales independientes; hace falta que las DOS
            // digan "ilustracion" para quitar la hoja blanca. Ante la duda
            // gana el camino seguro (hoja blanca), que nunca deja texto
            // ilegible.
            int boxCells = 0;
            int boxSolid = 0;
            int gapRows = 0;
            int totalRows = 0;
            int boxWidth = boxRight - boxLeft + 1;
            for (int y = boxTop; y <= boxBottom; y++) {
                int rowStart = y * gridWidth;
                int rowSolid = 0;
                for (int x = boxLeft; x <= boxRight; x++) {
                    boxCells++;
                    int alpha = (pixels[rowStart + x] >>> 24) & 0xFF;
                    if (alpha >= 200) {
                        boxSolid++;
                        rowSolid++;
                    }
                }
                totalRows++;
                // Fila "con hueco": mas de la mitad vacia. Entre renglon y
                // renglon de texto hay muchas; una ilustracion casi no tiene.
                if (rowSolid < boxWidth * 0.5f) gapRows++;
            }
            if (boxCells <= 0 || totalRows <= 0) return false;

            // Senal 1 - relleno: una ilustracion cubre casi todo su bloque.
            if (boxSolid < boxCells * 0.70f) return false;

            // Senal 2 - continuidad: una ilustracion no tiene renglones vacios
            // intercalados. Esta es la que distingue de verdad el texto, porque
            // el texto siempre deja papel entre linea y linea.
            if (gapRows > totalRows * 0.20f) return false;

            int outsideContent = 0;
            int outsideLimit = Math.max(4, Math.round(totalCells * 0.005f));
            for (int y = 0; y < gridHeight; y++) {
                boolean rowInside = y >= boxTop && y <= boxBottom;
                int rowStart = y * gridWidth;
                for (int x = 0; x < gridWidth; x++) {
                    if (rowInside && x >= boxLeft && x <= boxRight) continue;
                    int alpha = (pixels[rowStart + x] >>> 24) & 0xFF;
                    if (alpha >= 8) {
                        outsideContent++;
                        if (outsideContent > outsideLimit) return false;
                    }
                }
            }
            return true;
        } catch (Throwable ignored) {
            return false;
        } finally {
            if (small != null && !small.isRecycled()) small.recycle();
        }
    }

    public Bitmap exportPageBitmapHd(int targetPage, boolean includeRules) {
        return renderPageForExport(targetPage, includeRules, true);
    }

    private Bitmap renderPageForExport(int targetPage, boolean includeRules, boolean highDefinition) {
        synchronized (lock) {
            if (renderer == null || targetPage < 0 || targetPage >= pageCount) return null;

            PdfRenderer.Page page = null;
            Bitmap rendered = null;
            try {
                page = renderer.openPage(targetPage);
                float ratio = page.getHeight() / (float) Math.max(1, page.getWidth());
                int width;
                int height;
                int renderMode;

                if (highDefinition) {
                    width = 2800;
                    height = Math.max(1, Math.round(width * ratio));
                    if (height > 4600) {
                        height = 4600;
                        width = Math.max(1, Math.round(height / ratio));
                    }
                    renderMode = PdfRenderer.Page.RENDER_MODE_FOR_PRINT;
                } else {
                    width = Math.max(page.getWidth() * 2, 1200);
                    height = Math.max(1, Math.round(width * ratio));
                    if (height < 1600) {
                        height = 1600;
                        width = Math.max(1, Math.round(height / ratio));
                    }
                    renderMode = PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY;
                }

                rendered = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                rendered.eraseColor(Color.TRANSPARENT);
                page.render(rendered, null, null, renderMode);
                applyPageBackdrop(rendered);

                Canvas canvas = new Canvas(rendered);
                RectF pageRect = new RectF(0f, 0f, rendered.getWidth(), rendered.getHeight());
                drawMarkersForPage(canvas, pageRect, targetPage);
                if (includeRules) {
                    drawReadingRules(canvas, pageRect);
                }

                Bitmap result = rendered;
                rendered = null;
                return result;
            } catch (Exception e) {
                return null;
            } finally {
                if (rendered != null && !rendered.isRecycled()) rendered.recycle();
                if (page != null) page.close();
            }
        }
    }

    /**
     * Cierra el documento y apaga el hilo de renderizado. Debe llamarse cuando
     * la vista deja de usarse (cambio de tema o cierre de la pantalla): sin esto
     * cada vista nueva dejaba su hilo vivo para siempre.
     */
    public void release() {
        closeDocument();
        try {
            executor.shutdownNow();
            executor.awaitTermination(1, java.util.concurrent.TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (Exception ignored) {
        }
    }

    public void closeDocument() {
        documentOpenSerial++;
        serial++;
        pendingPage = -1;
        try {
            if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
            bitmap = null;

            synchronized (lock) {
                if (renderer != null) renderer.close();
                if (descriptor != null) descriptor.close();
                renderer = null;
                descriptor = null;
            }
        } catch (Exception ignored) {
        }

        pageCount = 0;
        pageIndex = 0;
        charBoxes = new ArrayList<CharBox>();
    }
}
