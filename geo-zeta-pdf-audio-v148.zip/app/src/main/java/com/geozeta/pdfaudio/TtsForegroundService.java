package com.geozeta.pdfaudio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.widget.RemoteViews;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class TtsForegroundService extends Service {
    public static final String ACTION_START = "com.geozeta.pdfaudio.START";
    public static final String ACTION_WARMUP = "com.geozeta.pdfaudio.WARMUP";
    public static final String ACTION_PREPARE = "com.geozeta.pdfaudio.PREPARE";
    public static final String ACTION_STOP = "com.geozeta.pdfaudio.STOP";
    public static final String ACTION_TOGGLE = "com.geozeta.pdfaudio.TOGGLE";
    public static final String ACTION_NEXT = "com.geozeta.pdfaudio.NEXT";
    public static final String ACTION_PREV = "com.geozeta.pdfaudio.PREV";
    public static final String ACTION_REPORT_RANGE = "com.geozeta.pdfaudio.REPORT_RANGE";
    public static final String ACTION_SEEK_PAGE = "com.geozeta.pdfaudio.SEEK_PAGE";
    public static final String ACTION_PAGE_CHANGED = "com.geozeta.pdfaudio.PAGE_CHANGED";

    public static final String EXTRA_PAGE = "page";
    public static final String EXTRA_AUTOPLAY = "autoplay";
    public static final String EXTRA_PAGE_TEXT = "page_text";
    public static final String EXTRA_FAST_RESUME_AUDIO = "fast_resume_audio";
    public static final String EXTRA_FAST_RESUME_TEXT = "fast_resume_text";
    public static final String EXTRA_TTS_LANGUAGE = "tts_language";
    public static final String EXTRA_TTS_REGION = "tts_region";
    public static final String ERROR_MISSING_VOICE_PREFIX = "VOICE_MISSING:";
    public static final String EXTRA_ACTIVE = "active";
    public static final String EXTRA_PAUSED = "paused";
    public static final String EXTRA_STATE = "playback_state";
    public static final String EXTRA_MESSAGE = "playback_message";
    public static final String EXTRA_CHUNK_TEXT = "reading_chunk_text";
    public static final String EXTRA_CHUNK_INDEX = "reading_chunk_index";
    public static final String EXTRA_RANGE_START = "reading_range_start";
    public static final String EXTRA_RANGE_END = "reading_range_end";

    public static final int STATE_STOPPED = 0;
    public static final int STATE_PREPARING = 1;
    public static final int STATE_PLAYING = 2;
    public static final int STATE_PAUSED = 3;
    public static final int STATE_ERROR = 4;

    private static final String CHANNEL_ID = "pdf_audio_playback_v69";
    private static final int NOTIFICATION_ID = 69;
    private static final String PREFS_NAME = "pdf_audio_prefs";
    private static final String PREF_TTS_ACTIVE = "tts_service_active";
    private static final String PREF_TTS_PAUSED = "tts_service_paused";
    private static final String PREF_TTS_CURRENT_PAGE = "tts_current_page";
    private static final String PREF_TTS_STATE = "tts_service_state";
    private static final String PREF_TTS_MESSAGE = "tts_service_message";

    public interface PageProvider {
        void requestPageText(int page, PageTextCallback callback);
    }

    public interface PageTextCallback {
        default void onFastText(String text) {}
        void onText(String text);
    }

    private static final Map<Integer, String> PAGE_MAP =
            new ConcurrentHashMap<Integer, String>();
    private static final Map<Integer, String> FAST_PAGE_MAP =
            new ConcurrentHashMap<Integer, String>();
    private static volatile PageProvider pageProvider;

    public static void setPageProvider(PageProvider provider) {
        pageProvider = provider;
    }

    public static void clearPages() {
        PAGE_MAP.clear();
        FAST_PAGE_MAP.clear();
    }


    public static void setPageText(int page, String text) {
        if (page >= 0) PAGE_MAP.put(page, text == null ? "" : text);
    }

    public static void setPageFastText(int page, String text) {
        if (page >= 0 && text != null && text.trim().length() > 0) {
            FAST_PAGE_MAP.put(page, text);
        }
    }


    private static volatile TtsForegroundService liveInstance;

    /**
     * True only when there is a real in-memory paused session that can resume
     * immediately on the requested page. Persisted PAUSED preferences alone are
     * not enough after the process/service has been recreated.
     */
    public static boolean canResumePausedPage(int page) {
        TtsForegroundService service = liveInstance;
        if (service == null) return false;
        if (service.playbackState != STATE_PAUSED || !service.paused
                || service.currentPageAbsolute != page) return false;
        if (service.fastResumeAudioActive && service.fastResumeAudioPaused
                && service.fastResumePlayer != null) return true;
        return service.currentChunks != null
                && !service.currentChunks.isEmpty()
                && service.currentChunkIndex >= 0
                && service.currentChunkIndex < service.currentChunks.size();
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private TtsEngineManager engineManager;
    private AudioManager audioManager;
    private AudioFocusRequest audioFocusRequest;
    private PowerManager.WakeLock wakeLock;

    private boolean reading;
    private boolean paused;
    private boolean waitingForProvider;
    private boolean foregroundStarted;
    private boolean currentUtteranceStarted;
    private boolean waitingForEngine;
    private boolean fastStartPageActive;
    private boolean waitingForFastStartRemainder;
    // Diagnostico de latencia: marca cuando el usuario pide audio y cuando el
    // motor entrega realmente el primer sonido. Solo escribe en el log.
    private long playRequestedAtMs;
    private String playRequestOrigin = "";
    private boolean latencyReported;
    private String fastStartSpokenText;
    private int playbackState = STATE_STOPPED;
    private int sessionId;
    private int currentPageAbsolute;
    private int totalPages;
    private int currentChunkIndex;
    private int chunkRetryCount;
    private int engineRestartCount;
    private boolean slowEngineRetryUsed;
    private int lastRangeStart;
    private int lastRangeEnd = 1;
    private List<String> currentChunks = Collections.emptyList();
    private String activeUtteranceId;
    private Runnable stallWatchdog;
    private int stallMissCount;
    private static final long STALL_CHECK_MS = 1100L;
    private String title = "PDF a Audio";
    private float rate = 1.0f;
    private float pitch = 1.0f;
    private String pdfLanguage = "";
    private String pdfRegion = "";
    private Runnable providerTimeout;
    private Runnable utteranceTimeout;
    private MediaPlayer fastResumePlayer;
    private boolean fastResumeAudioActive;
    private boolean fastResumeAudioPaused;
    private boolean hasSpokenInProcess;
    /**
     * Punto exacto (en caracteres, dentro del fragmento actual) donde quedo la
     * voz al pausar. Al reanudar se habla desde ahi en vez de volver al principio
     * del fragmento. Un fragmento puede ocupar casi toda la pagina, asi que
     * reiniciarlo era lo que hacia "subir" la seleccion al pausar y reanudar.
     */
    private int resumeCharOffset;
    /** Cuanto se recorto del principio del fragmento al enviarlo al motor. */
    private int spokenChunkOffset;
    /** Texto realmente entregado al motor en la orden en curso. */
    private String currentSpokenText = "";

    private final AudioManager.OnAudioFocusChangeListener focusChangeListener =
            new AudioManager.OnAudioFocusChangeListener() {
                @Override
                public void onAudioFocusChange(int focusChange) {
                    if (focusChange == AudioManager.AUDIOFOCUS_LOSS
                            && playbackState == STATE_PLAYING) {
                        pausePlayback();
                    }
                }
            };

    private final TtsEngineManager.UtteranceListener utteranceListener =
            new TtsEngineManager.UtteranceListener() {
                @Override
                public void onStart(final String utteranceId) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (!isCurrentUtterance(utteranceId) || !reading || paused) return;
                            cancelUtteranceTimeout();
                            reportPlayLatency("voz-motor");
                            currentUtteranceStarted = true;
                            hasSpokenInProcess = true;
                            chunkRetryCount = 0;
                            engineRestartCount = 0;
        slowEngineRetryUsed = false;
                            savePlaybackState(currentPageAbsolute, STATE_PLAYING,
                                    "Pagina " + (currentPageAbsolute + 1));
                            updateNotification("Pagina " + (currentPageAbsolute + 1)
                                    + " - " + String.format(Locale.US, "%.2fx", rate));
                            lastRangeStart = spokenChunkOffset;
                            lastRangeEnd = spokenChunkOffset + firstWordEnd(
                                    currentSpokenText != null && currentSpokenText.length() > 0
                                            ? currentSpokenText
                                            : currentChunks.get(currentChunkIndex));
                            broadcastReadingRange(lastRangeStart, lastRangeEnd);
                            // Desde que la voz arranca queda un vigilante despierto
                            // por si el motor deja de hablar sin avisar que termino.
                            startStallWatchdog(utteranceId);
                        }
                    });
                }

                @Override
                public void onDone(final String utteranceId) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (!isCurrentUtterance(utteranceId) || !reading || paused) return;
                            cancelUtteranceTimeout();
                            handleUtteranceFinished();
                        }
                    });
                }

                @Override
                public void onError(final String utteranceId, final int errorCode) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (!isCurrentUtterance(utteranceId) || !reading || paused) return;
                            cancelUtteranceTimeout();
                            if (chunkRetryCount < 1) {
                                chunkRetryCount++;
                                // El reintento tambien retoma desde donde iba la
                                // voz, no desde el principio del fragmento.
                                resumeCharOffset = Math.max(0, lastRangeStart);
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (reading && !paused
                                                && isCurrentUtterance(utteranceId)) {
                                            speakCurrentChunk();
                                        }
                                    }
                                }, 300L);
                            } else {
                                restartEngineOrFail("Error del motor de voz (codigo "
                                        + errorCode + ")");
                            }
                        }
                    });
                }

                @Override
                public void onStop(String utteranceId, boolean interrupted) {
                    // Stop is expected during pause, page changes and queue replacement.
                }

                @Override
                public void onRangeStart(final String utteranceId, final int start, final int end) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (!isCurrentUtterance(utteranceId) || !reading || paused) return;
                            int rawStart = Math.max(0, start);
                            int rawEnd = Math.max(rawStart + 1, end);
                            lastRangeStart = spokenChunkOffset + rawStart;
                            lastRangeEnd = spokenChunkOffset + rawEnd;
                            broadcastReadingRange(lastRangeStart, lastRangeEnd);
                        }
                    });
                }
            };

    @Override
    public void onCreate() {
        super.onCreate();
        liveInstance = this;
        createChannel();
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (powerManager != null) {
            wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                    "GeoZetaPdfAudio:TtsWakeLockV69");
            wakeLock.setReferenceCounted(false);
        }
        engineManager = TtsEngineManager.getInstance(this);
        engineManager.addUtteranceListener(utteranceListener);
        // V28: the service waits for the PDF language before starting TTS.
        // Initializing here could warm the wrong language and then immediately
        // recreate the engine when Play is pressed.
        // V98: no MediaStyle/MediaSession card. Keep the reader as a compact
        // foreground-service notification controlled by our own RemoteViews.
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || intent.getAction() == null) return START_NOT_STICKY;
        String action = intent.getAction();

        if (ACTION_WARMUP.equals(action)) {
            readCommonExtras(intent);
            if (pdfLanguage.length() > 0) engineManager.ensureLanguage(pdfLanguage, pdfRegion, null);
            else engineManager.initialize(null);
            return START_NOT_STICKY;
        }
        if (ACTION_PREPARE.equals(action)) {
            prepareForNewPage(intent);
            return START_NOT_STICKY;
        }
        if (ACTION_START.equals(action)) {
            startPlayback(intent);
        } else if (ACTION_TOGGLE.equals(action)) {
            if (playbackState == STATE_PAUSED) resumePlayback();
            else if (playbackState == STATE_PLAYING) pausePlayback();
            else if (playbackState == STATE_PREPARING) pausePendingPlayback();
        } else if (ACTION_SEEK_PAGE.equals(action)) {
            readCommonExtras(intent);
            int requestedPage = intent.getIntExtra(EXTRA_PAGE, currentPageAbsolute);
            String suppliedText = intent.getStringExtra(EXTRA_PAGE_TEXT);
            if (suppliedText != null && requestedPage >= 0) {
                PAGE_MAP.put(requestedPage, suppliedText);
            }
            seekToPage(requestedPage,
                    intent.getBooleanExtra(EXTRA_AUTOPLAY, true));
        } else if (ACTION_NEXT.equals(action)) {
            jumpToPage(currentPageAbsolute + 1);
        } else if (ACTION_PREV.equals(action)) {
            jumpToPage(Math.max(0, currentPageAbsolute - 1));
        } else if (ACTION_REPORT_RANGE.equals(action)) {
            if ((reading || paused) && currentChunkIndex >= 0
                    && currentChunkIndex < currentChunks.size()) {
                broadcastReadingRange(lastRangeStart, lastRangeEnd);
            } else {
                savePlaybackState(currentPageAbsolute, playbackState,
                        "Pagina " + (currentPageAbsolute + 1));
            }
        } else if (ACTION_STOP.equals(action)) {
            stopAll();
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    /**
     * Marca el instante en que el usuario pidio audio. Se conserva porque el
     * resto del servicio consulta si ya hubo un pedido en curso.
     */
    private void markPlayRequested(String origin) {
        playRequestedAtMs = android.os.SystemClock.elapsedRealtime();
        playRequestOrigin = origin == null ? "" : origin;
        latencyReported = false;
    }

    /** Cierra el pedido en curso cuando ya sono la primera palabra. */
    private void reportPlayLatency(String howItStarted) {
        if (latencyReported || playRequestedAtMs <= 0L) return;
        latencyReported = true;
    }

    private void prepareForNewPage(Intent intent) {
        sessionId++;
        cancelProviderTimeout();
        cancelUtteranceTimeout();
        releaseFastResumePlayer();
        waitingForProvider = false;
        waitingForEngine = false;
        reading = false;
        paused = false;
        currentChunks = Collections.emptyList();
        currentChunkIndex = 0;
        lastRangeStart = 0;
        lastRangeEnd = 1;
        activeUtteranceId = null;
        currentUtteranceStarted = false;
        fastStartPageActive = false;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = null;
        engineManager.stop();
        readCommonExtras(intent);
        ensureForeground("Preparando pagina " + (currentPageAbsolute + 1));
        savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                "Preparando pagina " + (currentPageAbsolute + 1));
    }

    private void startPlayback(Intent intent) {
        sessionId++;
        cancelProviderTimeout();
        cancelUtteranceTimeout();
        releaseFastResumePlayer();
        waitingForProvider = false;
        waitingForEngine = false;
        readCommonExtras(intent);
        currentPageAbsolute = Math.max(0, intent.getIntExtra("pageOffset", currentPageAbsolute)
                + Math.max(0, intent.getIntExtra("startIndex", 0)));
        currentChunks = Collections.emptyList();
        currentChunkIndex = 0;
        lastRangeStart = 0;
        lastRangeEnd = 1;
        activeUtteranceId = null;
        currentUtteranceStarted = false;
        fastStartPageActive = false;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = null;
        chunkRetryCount = 0;
        engineRestartCount = 0;
        slowEngineRetryUsed = false;
        reading = true;
        paused = false;
        markPlayRequested("play");
        // No detenemos el motor antes de cada Play. QUEUE_FLUSH reemplaza la cola
        // anterior y evita el costo de reiniciar la salida de voz.
        ensureForeground("Preparando pagina " + (currentPageAbsolute + 1));
        savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                "Preparando pagina " + (currentPageAbsolute + 1));

        // En un arranque frio, el audio corto persistido habla de inmediato y
        // oculta el tiempo que Android necesita para volver a crear el TTS.
        if (!hasSpokenInProcess && startFastResumeAudio(intent, sessionId)) {
            if (pdfLanguage.length() > 0) engineManager.ensureLanguage(pdfLanguage, pdfRegion, null);
            else engineManager.initialize(null);
            return;
        }
        startWhenEngineReady(sessionId);
    }

    private boolean startFastResumeAudio(Intent intent, final int requestSession) {
        String path = intent.getStringExtra(EXTRA_FAST_RESUME_AUDIO);
        String spokenText = cleanForTts(intent.getStringExtra(EXTRA_FAST_RESUME_TEXT));
        if (path == null || path.trim().length() == 0 || spokenText.length() == 0) return false;
        java.io.File file = new java.io.File(path);
        if (!file.exists() || file.length() <= 64L) return false;

        try {
            final MediaPlayer player = new MediaPlayer();
            if (Build.VERSION.SDK_INT >= 21) {
                player.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build());
            }
            player.setDataSource(file.getAbsolutePath());
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (requestSession != sessionId || !fastResumeAudioActive) return;
                            releaseFastResumePlayer();
                            if (!reading || paused) return;
                            savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                                    "Continuando pagina " + (currentPageAbsolute + 1));
                            updateNotification("Continuando pagina " + (currentPageAbsolute + 1));
                            if (engineManager.isReady()) {
                                continueAfterFastStart();
                            } else {
                                waitForEngineAfterFastResume(requestSession);
                            }
                        }
                    });
                }
            });
            player.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer mp, int what, int extra) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (requestSession != sessionId) return;
                            releaseFastResumePlayer();
                            fastStartPageActive = false;
                            waitingForFastStartRemainder = false;
                            fastStartSpokenText = null;
                            if (reading && !paused) startWhenEngineReady(requestSession);
                        }
                    });
                    return true;
                }
            });
            player.prepare();

            fastResumePlayer = player;
            fastResumeAudioActive = true;
            fastResumeAudioPaused = false;
            fastStartPageActive = true;
            waitingForFastStartRemainder = false;
            fastStartSpokenText = spokenText;
            currentChunks = Collections.emptyList();
            currentChunkIndex = 0;
            activeUtteranceId = null;
            currentUtteranceStarted = false;
            acquirePlaybackResources();
            player.start();
            reportPlayLatency("audio-puente");
            savePlaybackState(currentPageAbsolute, STATE_PLAYING,
                    "Pagina " + (currentPageAbsolute + 1));
            updateNotification("Pagina " + (currentPageAbsolute + 1)
                    + " - " + String.format(Locale.US, "%.2fx", rate));
            return true;
        } catch (Exception ignored) {
            releaseFastResumePlayer();
            fastStartPageActive = false;
            waitingForFastStartRemainder = false;
            fastStartSpokenText = null;
            return false;
        }
    }

    private void waitForEngineAfterFastResume(final int requestSession) {
        if (requestSession != sessionId || !reading || paused) return;
        if (engineManager.isReady() && (pdfLanguage.length() == 0
                || (engineManager.isPreferredLanguageAvailable()
                && pdfLanguage.equals(engineManager.getPreferredLanguage())))) {
            waitingForEngine = false;
            continueAfterFastStart();
            return;
        }
        if (waitingForEngine) return;
        waitingForEngine = true;
        TtsEngineManager.ReadyCallback callback = new TtsEngineManager.ReadyCallback() {
            @Override
            public void onReady(String enginePackage) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (requestSession == sessionId && reading && !paused) {
                            waitingForEngine = false;
                            continueAfterFastStart();
                        }
                    }
                });
            }

            @Override
            public void onError(final String message) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (requestSession == sessionId && reading && !paused) {
                            waitingForEngine = false;
                            if (retryAfterSlowEngine(message, requestSession)) return;
                            failPlayback(message);
                        }
                    }
                });
            }
        };
        if (pdfLanguage.length() > 0) engineManager.ensureLanguage(pdfLanguage, pdfRegion, callback);
        else engineManager.initialize(callback);
    }

    private void startWhenEngineReady(final int requestSession) {
        if (engineManager.isReady() && (pdfLanguage.length() == 0
                || (engineManager.isPreferredLanguageAvailable()
                && pdfLanguage.equals(engineManager.getPreferredLanguage())))) {
            waitingForEngine = false;
            speakAbsolutePage(currentPageAbsolute);
            return;
        }
        if (waitingForEngine) return;
        waitingForEngine = true;
        savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                "Iniciando motor de voz");
        updateNotification("Iniciando motor de voz");
        TtsEngineManager.ReadyCallback callback = new TtsEngineManager.ReadyCallback() {
            @Override
            public void onReady(String enginePackage) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (requestSession == sessionId && reading && !paused) {
                            waitingForEngine = false;
                            speakAbsolutePage(currentPageAbsolute);
                        }
                    }
                });
            }

            @Override
            public void onError(final String message) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (requestSession == sessionId && reading && !paused) {
                            waitingForEngine = false;
                            if (retryAfterSlowEngine(message, requestSession)) return;
                            failPlayback(message);
                        }
                    }
                });
            }
        };
        if (pdfLanguage.length() > 0) engineManager.ensureLanguage(pdfLanguage, pdfRegion, callback);
        else engineManager.initialize(callback);
    }

    private void readCommonExtras(Intent intent) {
        String extraTitle = intent.getStringExtra("title");
        if (extraTitle != null && extraTitle.trim().length() > 0) title = extraTitle;
        totalPages = Math.max(0, intent.getIntExtra("totalPages", totalPages));
        currentPageAbsolute = Math.max(0,
                intent.getIntExtra("pageOffset", currentPageAbsolute));
        rate = clampRate(intent.getFloatExtra("rate", rate));
        pitch = clampPitch(intent.getFloatExtra("pitch", pitch));

        String extraLanguage = intent.getStringExtra(EXTRA_TTS_LANGUAGE);
        if (extraLanguage != null) pdfLanguage = PdfLanguageDetector.normalizeCode(extraLanguage);
        String extraRegion = intent.getStringExtra(EXTRA_TTS_REGION);
        if (extraRegion != null) pdfRegion = extraRegion.trim().toUpperCase(Locale.ROOT);
        if (pdfLanguage.length() > 0) engineManager.setPreferredLanguage(pdfLanguage, pdfRegion);
    }

    private void jumpToPage(int targetPage) {
        seekToPage(targetPage, true);
    }

    private void seekToPage(int targetPage, boolean autoplay) {
        if (totalPages > 0) targetPage = Math.min(targetPage, totalPages - 1);
        sessionId++;
        cancelProviderTimeout();
        cancelUtteranceTimeout();
        releaseFastResumePlayer();
        engineManager.stop();
        currentPageAbsolute = Math.max(0, targetPage);
        currentChunks = Collections.emptyList();
        currentChunkIndex = 0;
        resumeCharOffset = 0;
        spokenChunkOffset = 0;
        currentSpokenText = "";
        activeUtteranceId = null;
        currentUtteranceStarted = false;
        fastStartPageActive = false;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = null;
        waitingForProvider = false;
        waitingForEngine = false;
        engineRestartCount = 0;
        slowEngineRetryUsed = false;
        lastRangeStart = 0;
        lastRangeEnd = 1;

        if (autoplay) {
            reading = true;
            paused = false;
            markPlayRequested("cambio-pagina");
            ensureForeground("Preparando pagina " + (currentPageAbsolute + 1));
            savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                    "Preparando pagina " + (currentPageAbsolute + 1));
            startWhenEngineReady(sessionId);
        } else {
            reading = false;
            paused = true;
            savePlaybackState(currentPageAbsolute, STATE_PAUSED, "Pausado");
            if (foregroundStarted) updateNotification("Pausado");
            releaseAudioFocus();
            releaseWakeLock();
        }
    }

    private void pausePendingPlayback() {
        sessionId++;
        cancelProviderTimeout();
        cancelUtteranceTimeout();
        releaseFastResumePlayer();
        engineManager.stop();
        waitingForProvider = false;
        waitingForEngine = false;
        currentChunks = Collections.emptyList();
        currentChunkIndex = 0;
        resumeCharOffset = 0;
        spokenChunkOffset = 0;
        currentSpokenText = "";
        activeUtteranceId = null;
        currentUtteranceStarted = false;
        fastStartPageActive = false;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = null;
        reading = false;
        paused = true;
        savePlaybackState(currentPageAbsolute, STATE_PAUSED, "Pausado");
        if (foregroundStarted) updateNotification("Pausado");
        releaseAudioFocus();
        releaseWakeLock();
    }

    private void speakCurrentPageOrChunk() {
        if (!reading || paused) return;
        if (!currentChunks.isEmpty() && currentChunkIndex < currentChunks.size()) {
            speakCurrentChunk();
        } else {
            speakAbsolutePage(currentPageAbsolute);
        }
    }

    private void speakAbsolutePage(final int absolutePage) {
        if (!reading || paused) return;
        if (!engineManager.isReady() || (pdfLanguage.length() > 0
                && (!engineManager.isPreferredLanguageAvailable()
                || !pdfLanguage.equals(engineManager.getPreferredLanguage())))) {
            startWhenEngineReady(sessionId);
            return;
        }
        if (totalPages > 0 && absolutePage >= totalPages) {
            finishPlayback();
            return;
        }

        String stored = PAGE_MAP.get(absolutePage);
        if (stored != null) {
            speakTextForPage(absolutePage, stored);
            return;
        }
        String fast = FAST_PAGE_MAP.get(absolutePage);
        if (fast != null && fast.trim().length() > 0) {
            speakFastTextForPage(absolutePage, fast);
            return;
        }
        requestPageFromProvider(absolutePage);
    }

    private void requestPageFromProvider(final int absolutePage) {
        if (!reading || paused || waitingForProvider) return;
        final PageProvider provider = pageProvider;
        if (provider == null) {
            failPlayback("La aplicacion no pudo obtener el texto de la pagina");
            return;
        }

        waitingForProvider = true;
        final int requestSession = sessionId;
        savePlaybackState(absolutePage, STATE_PREPARING,
                "Preparando pagina " + (absolutePage + 1));
        updateNotification("Preparando pagina " + (absolutePage + 1));

        providerTimeout = new Runnable() {
            @Override
            public void run() {
                if (requestSession == sessionId && waitingForProvider && reading && !paused) {
                    waitingForProvider = false;
                    failPlayback("El PDF tardo demasiado en entregar el texto");
                }
            }
        };
        handler.postDelayed(providerTimeout, 15000L);

        try {
            provider.requestPageText(absolutePage, new PageTextCallback() {
                @Override
                public void onFastText(final String text) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (requestSession != sessionId
                                    || absolutePage != currentPageAbsolute
                                    || !reading || paused || PAGE_MAP.containsKey(absolutePage)
                                    || fastStartPageActive) return;
                            String fast = text == null ? "" : text.trim();
                            if (fast.length() == 0) return;
                            cancelProviderTimeout();
                            waitingForProvider = false;
                            FAST_PAGE_MAP.put(absolutePage, fast);
                            speakFastTextForPage(absolutePage, fast);
                        }
                    });
                }

                @Override
                public void onText(final String text) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (requestSession != sessionId
                                    || absolutePage != currentPageAbsolute
                                    || !reading || paused) return;
                            cancelProviderTimeout();
                            waitingForProvider = false;
                            PAGE_MAP.put(absolutePage, text == null ? "" : text);
                            if (fastStartPageActive) {
                                if (waitingForFastStartRemainder) {
                                    speakRemainderAfterFastStart(absolutePage, text);
                                }
                                return;
                            }
                            speakTextForPage(absolutePage, text);
                        }
                    });
                }
            });
        } catch (Exception ignored) {
            cancelProviderTimeout();
            waitingForProvider = false;
            failPlayback("No se pudo extraer el texto de la pagina");
        }
    }

    private void speakTextForPage(int absolutePage, String rawText) {
        fastStartPageActive = false;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = null;
        speakPreparedTextForPage(absolutePage, rawText);
    }

    private void speakFastTextForPage(int absolutePage, String rawText) {
        String fast = cleanForTts(rawText);
        if (fast.length() == 0) {
            requestPageFromProvider(absolutePage);
            return;
        }
        fastStartPageActive = true;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = fast;
        speakPreparedTextForPage(absolutePage, fast);
    }

    private void speakPreparedTextForPage(int absolutePage, String rawText) {
        if (!reading || paused || absolutePage != currentPageAbsolute) return;
        String text = cleanForTts(rawText);
        if (text.length() == 0) {
            advancePastUnreadablePage();
            return;
        }

        currentChunks = splitText(text);
        currentChunkIndex = 0;
        resumeCharOffset = 0;
        spokenChunkOffset = 0;
        currentSpokenText = "";
        lastRangeStart = 0;
        lastRangeEnd = currentChunks.isEmpty() ? 1 : firstWordEnd(currentChunks.get(0));
        chunkRetryCount = 0;
        if (currentChunks.isEmpty()) {
            advancePastUnreadablePage();
            return;
        }
        speakCurrentChunk();
    }

    private boolean continueAfterFastStart() {
        if (!fastStartPageActive || !reading || paused) return false;
        String full = PAGE_MAP.get(currentPageAbsolute);
        if (full != null) {
            speakRemainderAfterFastStart(currentPageAbsolute, full);
            return true;
        }

        currentChunks = Collections.emptyList();
        currentChunkIndex = 0;
        resumeCharOffset = 0;
        spokenChunkOffset = 0;
        currentSpokenText = "";
        activeUtteranceId = null;
        currentUtteranceStarted = false;
        waitingForFastStartRemainder = true;
        savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                "Completando pagina " + (currentPageAbsolute + 1));
        requestPageFromProvider(currentPageAbsolute);
        return true;
    }

    private void speakRemainderAfterFastStart(int absolutePage, String fullText) {
        if (!reading || paused || absolutePage != currentPageAbsolute) return;
        String full = cleanForTts(fullText);
        String spoken = cleanForTts(fastStartSpokenText);
        String remainder = removeSpokenPrefix(full, spoken);

        fastStartPageActive = false;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = null;
        FAST_PAGE_MAP.remove(absolutePage);

        if (remainder.length() == 0) {
            advanceToNextPage();
            return;
        }
        speakPreparedTextForPage(absolutePage, remainder);
    }

    private String removeSpokenPrefix(String full, String spoken) {
        if (full == null) return "";
        String safeFull = cleanForTts(full);
        String safeSpoken = cleanForTts(spoken);
        if (safeSpoken.length() == 0) return safeFull;
        if (safeFull.startsWith(safeSpoken)) {
            return safeFull.substring(safeSpoken.length()).trim();
        }

        String[] fullWords = safeFull.split("\\s+");
        String[] spokenWords = safeSpoken.split("\\s+");
        int matched = 0;
        int limit = Math.min(fullWords.length, spokenWords.length);
        while (matched < limit && normalizedWord(fullWords[matched])
                .equals(normalizedWord(spokenWords[matched]))) {
            matched++;
        }
        int required = Math.min(spokenWords.length, Math.max(3, spokenWords.length * 2 / 3));
        if (matched >= required && matched > 0) {
            StringBuilder remainder = new StringBuilder();
            for (int i = matched; i < fullWords.length; i++) {
                if (remainder.length() > 0) remainder.append(' ');
                remainder.append(fullWords[i]);
            }
            return remainder.toString().trim();
        }

        int tailLength = Math.min(28, safeSpoken.length());
        if (tailLength >= 10) {
            String tail = safeSpoken.substring(safeSpoken.length() - tailLength);
            int maxSearch = Math.min(safeFull.length(), Math.max(500, safeSpoken.length() * 3));
            int found = safeFull.substring(0, maxSearch).indexOf(tail);
            if (found >= 0) {
                return safeFull.substring(found + tail.length()).trim();
            }
        }

        int approximate = Math.min(safeFull.length(), safeSpoken.length());
        while (approximate < safeFull.length()
                && !Character.isWhitespace(safeFull.charAt(approximate))) {
            approximate++;
        }
        return safeFull.substring(Math.min(approximate, safeFull.length())).trim();
    }

    private String normalizedWord(String value) {
        if (value == null) return "";
        return value.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]", "");
    }

    private void advanceToNextPage() {
        currentPageAbsolute++;
        currentChunkIndex = 0;
        currentChunks = Collections.emptyList();
        activeUtteranceId = null;
        currentUtteranceStarted = false;
        fastStartPageActive = false;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = null;
        if (totalPages > 0 && currentPageAbsolute >= totalPages) {
            finishPlayback();
        } else {
            savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                    "Preparando pagina " + (currentPageAbsolute + 1));
            speakAbsolutePage(currentPageAbsolute);
        }
    }

    private void advancePastUnreadablePage() {
        fastStartPageActive = false;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = null;
        currentPageAbsolute++;
        currentChunks = Collections.emptyList();
        currentChunkIndex = 0;
        resumeCharOffset = 0;
        spokenChunkOffset = 0;
        currentSpokenText = "";
        activeUtteranceId = null;
        currentUtteranceStarted = false;
        if (totalPages > 0 && currentPageAbsolute >= totalPages) {
            finishPlayback();
            return;
        }
        savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                "Preparando pagina " + (currentPageAbsolute + 1));
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (reading && !paused) speakAbsolutePage(currentPageAbsolute);
            }
        });
    }

    private void speakCurrentChunk() {
        if (!reading || paused) return;
        if (!engineManager.isReady() || (pdfLanguage.length() > 0
                && (!engineManager.isPreferredLanguageAvailable()
                || !pdfLanguage.equals(engineManager.getPreferredLanguage())))) {
            startWhenEngineReady(sessionId);
            return;
        }
        if (currentChunkIndex < 0 || currentChunkIndex >= currentChunks.size()) {
            failPlayback("El audio no pudo preparar el texto");
            return;
        }

        acquirePlaybackResources();
        engineManager.setSpeechRate(rate);
        engineManager.setPitch(pitch);

        final String fullChunk = currentChunks.get(currentChunkIndex);
        int offset = resumeCharOffset;
        if (offset < 0 || offset >= fullChunk.length()) offset = 0;
        // Se retrocede hasta el principio de la palabra para no cortarla al medio.
        while (offset > 0 && !Character.isWhitespace(fullChunk.charAt(offset - 1))) offset--;
        String textToSpeak = offset > 0 ? fullChunk.substring(offset) : fullChunk;
        if (textToSpeak.trim().length() == 0) {
            offset = 0;
            textToSpeak = fullChunk;
        }
        resumeCharOffset = 0;
        spokenChunkOffset = offset;
        currentSpokenText = textToSpeak;

        lastRangeStart = spokenChunkOffset;
        lastRangeEnd = spokenChunkOffset + firstWordEnd(textToSpeak);

        final int requestSession = sessionId;
        final String utteranceId = "S" + requestSession + "_P" + currentPageAbsolute
                + "_C" + currentChunkIndex + "_O" + spokenChunkOffset
                + "_R" + chunkRetryCount;
        activeUtteranceId = utteranceId;
        currentUtteranceStarted = false;

        Bundle params = new Bundle();
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f);
        int result = engineManager.speak(textToSpeak,
                TextToSpeech.QUEUE_FLUSH, params, utteranceId);
        if (result == TextToSpeech.ERROR) {
            handleSpeakRejected(requestSession);
            return;
        }
        // El seguimiento visual puede aparecer de inmediato, sin esperar a que el
        // motor devuelva onRangeStart. onStart/onRangeStart lo corrigen después.
        broadcastReadingRange(lastRangeStart, lastRangeEnd);
        scheduleUtteranceCheck(requestSession, utteranceId);
    }

    private void scheduleUtteranceCheck(final int requestSession, final String utteranceId) {
        cancelUtteranceTimeout();
        utteranceTimeout = new Runnable() {
            @Override
            public void run() {
                if (requestSession != sessionId || !isCurrentUtterance(utteranceId)
                        || !reading || paused || currentUtteranceStarted) return;
                if (engineManager.isSpeaking()) {
                    currentUtteranceStarted = true;
                    savePlaybackState(currentPageAbsolute, STATE_PLAYING,
                            "Pagina " + (currentPageAbsolute + 1));
                    updateNotification("Pagina " + (currentPageAbsolute + 1)
                            + " - " + String.format(Locale.US, "%.2fx", rate));
                } else if (chunkRetryCount < 1) {
                    chunkRetryCount++;
                    speakCurrentChunk();
                } else {
                    restartEngineOrFail("El motor recibio el texto pero no inicio el audio");
                }
            }
        };
        // Algunos motores TTS tardan varios segundos en entregar el primer
        // onStart despues de un arranque en frio. No tratar una inicializacion
        // normal como fallo ni reiniciar el motor demasiado pronto.
        long startGraceMs = hasSpokenInProcess ? 2600L : 5200L;
        handler.postDelayed(utteranceTimeout, startGraceMs);
    }

    private void handleSpeakRejected(final int requestSession) {
        if (requestSession != sessionId || !reading || paused) return;
        if (chunkRetryCount < 1) {
            chunkRetryCount++;
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (requestSession == sessionId && reading && !paused) {
                        speakCurrentChunk();
                    }
                }
            }, 300L);
        } else {
            restartEngineOrFail("El motor de voz rechazo el texto");
        }
    }

    private void restartEngineOrFail(String finalMessage) {
        if (engineRestartCount < 1 && reading && !paused) {
            engineRestartCount++;
            chunkRetryCount = 0;
            waitingForEngine = false;
            currentUtteranceStarted = false;
            activeUtteranceId = null;
            cancelUtteranceTimeout();
            savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                    "Reiniciando motor de voz");
            updateNotification("Reiniciando motor de voz");
            engineManager.retryInitialization();
            startWhenEngineReady(sessionId);
        } else {
            failPlayback(finalMessage);
        }
    }

    private boolean isCurrentUtterance(String utteranceId) {
        return utteranceId != null && utteranceId.equals(activeUtteranceId);
    }

    private List<String> splitText(String text) {
        if (text == null || text.trim().length() == 0) return Collections.emptyList();
        int engineLimit = TextToSpeech.getMaxSpeechInputLength();
        int maxLength = Math.max(700, Math.min(2800, engineLimit - 300));
        ArrayList<String> chunks = new ArrayList<String>();
        String remaining = text.trim();

        // Arranque rapido: la primera orden contiene solo la primera frase o linea
        // util. Mientras se escucha, el resto de la pagina ya queda dividido en RAM.
        int fastStartMax = Math.min(72, maxLength);
        if (remaining.length() > fastStartMax) {
            int split = findFastStartSplitPoint(remaining, fastStartMax);
            String firstChunk = remaining.substring(0, split).trim();
            if (firstChunk.length() > 0) chunks.add(firstChunk);
            remaining = remaining.substring(split).trim();
        }

        // Los siguientes bloques siguen siendo grandes para conservar continuidad y
        // no introducir pausas innecesarias durante la lectura de la pagina.
        while (remaining.length() > maxLength) {
            int minimum = Math.max(1, (int) (maxLength * 0.55f));
            int split = findSplitPoint(remaining, minimum, maxLength);
            String chunk = remaining.substring(0, split).trim();
            if (chunk.length() > 0) chunks.add(chunk);
            remaining = remaining.substring(split).trim();
        }
        if (remaining.length() > 0) chunks.add(remaining);
        return chunks;
    }

    private int findFastStartSplitPoint(String value, int maximum) {
        int safeMaximum = Math.min(maximum, value.length());
        int minimum = Math.min(28, Math.max(1, safeMaximum / 4));

        // Se elige el primer cierre natural, no el ultimo, para soltar la voz antes.
        for (int i = minimum; i < safeMaximum; i++) {
            char c = value.charAt(i);
            if (c == '.' || c == '!' || c == '?' || c == ';' || c == ':' || c == '\n') {
                return i + 1;
            }
        }
        for (int i = safeMaximum - 1; i >= minimum; i--) {
            if (Character.isWhitespace(value.charAt(i))) return i + 1;
        }
        return safeMaximum;
    }

    private int findSplitPoint(String value, int minimum, int maximum) {
        int safeMaximum = Math.min(maximum, value.length());
        for (int i = safeMaximum - 1; i >= minimum; i--) {
            char c = value.charAt(i);
            if (c == '.' || c == '!' || c == '?' || c == ';' || c == ':' || c == '\n') {
                return i + 1;
            }
        }
        for (int i = safeMaximum - 1; i >= minimum; i--) {
            if (Character.isWhitespace(value.charAt(i))) return i + 1;
        }
        return safeMaximum;
    }

    private void pausePlayback() {
        if (playbackState != STATE_PLAYING) return;
        cancelUtteranceTimeout();
        if (fastResumeAudioActive && fastResumePlayer != null) {
            try { fastResumePlayer.pause(); } catch (Exception ignored) {}
            fastResumeAudioPaused = true;
            reading = false;
            paused = true;
            savePlaybackState(currentPageAbsolute, STATE_PAUSED, "Pausado");
            updateNotification("Pausado");
            releaseAudioFocus();
            releaseWakeLock();
            return;
        }
        reading = false;
        paused = true;
        // Se anota donde iba la voz para reanudar exactamente ahi.
        resumeCharOffset = Math.max(0, lastRangeStart);
        engineManager.stop();
        savePlaybackState(currentPageAbsolute, STATE_PAUSED, "Pausado");
        updateNotification("Pausado");
        releaseAudioFocus();
        releaseWakeLock();
    }

    private void resumePlayback() {
        if (playbackState != STATE_PAUSED) return;
        markPlayRequested("reanudar");
        if (fastResumeAudioActive && fastResumeAudioPaused && fastResumePlayer != null) {
            reading = true;
            paused = false;
            fastResumeAudioPaused = false;
            acquirePlaybackResources();
            try {
                fastResumePlayer.start();
                reportPlayLatency("audio-puente-reanudar");
                savePlaybackState(currentPageAbsolute, STATE_PLAYING,
                        "Pagina " + (currentPageAbsolute + 1));
                updateNotification("Pagina " + (currentPageAbsolute + 1)
                        + " - " + String.format(Locale.US, "%.2fx", rate));
                return;
            } catch (Exception ignored) {
                releaseFastResumePlayer();
            }
        }
        reading = true;
        paused = false;
        chunkRetryCount = 0;
        ensureForeground("Preparando pagina " + (currentPageAbsolute + 1));
        savePlaybackState(currentPageAbsolute, STATE_PREPARING,
                "Reanudando pagina " + (currentPageAbsolute + 1));
        speakCurrentPageOrChunk();
    }

    private void finishPlayback() {
        releaseFastResumePlayer();
        reading = false;
        paused = false;
        resumeCharOffset = 0;
        spokenChunkOffset = 0;
        currentSpokenText = "";
        waitingForProvider = false;
        waitingForEngine = false;
        fastStartPageActive = false;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = null;
        cancelProviderTimeout();
        cancelUtteranceTimeout();
        savePlaybackState(Math.max(0, currentPageAbsolute - 1), STATE_STOPPED,
                "Lectura finalizada");
        updateNotification("Lectura finalizada");
        releaseAudioFocus();
        releaseWakeLock();
        stopForeground(true);
        foregroundStarted = false;
        // El servicio queda caliente para que el siguiente Play no cree otra vez
        // el motor. Android puede liberarlo si necesita memoria.
    }

    private void stopAll() {
        releaseFastResumePlayer();
        sessionId++;
        reading = false;
        paused = false;
        waitingForProvider = false;
        waitingForEngine = false;
        cancelProviderTimeout();
        cancelUtteranceTimeout();
        currentChunks = Collections.emptyList();
        currentChunkIndex = 0;
        resumeCharOffset = 0;
        spokenChunkOffset = 0;
        currentSpokenText = "";
        activeUtteranceId = null;
        currentUtteranceStarted = false;
        fastStartPageActive = false;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = null;
        engineManager.stop();
        savePlaybackState(currentPageAbsolute, STATE_STOPPED, "Detenido");
        releaseAudioFocus();
        releaseWakeLock();
        stopForeground(true);
        foregroundStarted = false;
        // Se conserva el servicio y el motor para el siguiente Play.
    }

    /**
     * Si el motor solo tardo demasiado en encender, se vuelve a intentar solo,
     * una vez, sin molestar al usuario. Es lo mismo que el usuario conseguia
     * apretando Play por segunda vez.
     */
    private boolean retryAfterSlowEngine(String message, final int requestSession) {
        if (message == null || !TtsEngineManager.ERROR_ENGINE_SLOW.equals(message)) return false;
        if (slowEngineRetryUsed) return false;
        slowEngineRetryUsed = true;
        savePlaybackState(currentPageAbsolute, STATE_PREPARING, "Iniciando motor de voz");
        updateNotification("Iniciando motor de voz");
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (requestSession != sessionId || !reading || paused) return;
                startWhenEngineReady(requestSession);
            }
        }, 500L);
        return true;
    }

    private void failPlayback(String message) {
        releaseFastResumePlayer();
        sessionId++;
        reading = false;
        paused = false;
        resumeCharOffset = 0;
        spokenChunkOffset = 0;
        currentSpokenText = "";
        waitingForProvider = false;
        waitingForEngine = false;
        fastStartPageActive = false;
        waitingForFastStartRemainder = false;
        fastStartSpokenText = null;
        cancelProviderTimeout();
        cancelUtteranceTimeout();
        engineManager.stop();
        savePlaybackState(currentPageAbsolute, STATE_ERROR, message);
        if (foregroundStarted) updateNotification(message);
        releaseAudioFocus();
        releaseWakeLock();
        stopForeground(true);
        foregroundStarted = false;
        // Incluso tras un error, el administrador TTS permanece disponible.
    }

    private void releaseFastResumePlayer() {
        MediaPlayer player = fastResumePlayer;
        fastResumePlayer = null;
        fastResumeAudioActive = false;
        fastResumeAudioPaused = false;
        if (player != null) {
            try { player.setOnCompletionListener(null); } catch (Exception ignored) {}
            try { player.setOnErrorListener(null); } catch (Exception ignored) {}
            try { player.stop(); } catch (Exception ignored) {}
            try { player.release(); } catch (Exception ignored) {}
        }
    }

    private void cancelProviderTimeout() {
        if (providerTimeout != null) {
            handler.removeCallbacks(providerTimeout);
            providerTimeout = null;
        }
    }

    /**
     * Continua la lectura cuando el fragmento actual ya termino: pasa al
     * siguiente trozo, o a la pagina siguiente si no quedan trozos.
     */
    private void handleUtteranceFinished() {
        if (currentChunkIndex + 1 < currentChunks.size()) {
            currentChunkIndex++;
            speakCurrentChunk();
            return;
        }
        if (fastStartPageActive && continueAfterFastStart()) {
            return;
        }
        advanceToNextPage();
    }

    /**
     * Vigilante contra el silencio.
     *
     * El aviso onDone del motor de voz no siempre llega. Pasa sobre todo cuando
     * el motor llevaba rato sin usarse: habla la frase y despues no avisa nada,
     * asi que la app se queda esperando un aviso que no va a venir y la lectura
     * se corta sin motivo aparente.
     *
     * El control que ya existia solo miraba si la voz habia arrancado, y se
     * apagaba en cuanto sonaba la primera palabra. Este otro se queda despierto
     * mientras dura el fragmento: si el motor deja de hablar y el aviso no
     * llego, continua igual. Se exigen dos comprobaciones seguidas en silencio
     * antes de actuar, porque justo despues de arrancar el motor puede informar
     * que no esta hablando durante un instante.
     */
    private void startStallWatchdog(final String utteranceId) {
        cancelStallWatchdog();
        final int requestSession = sessionId;
        stallMissCount = 0;
        stallWatchdog = new Runnable() {
            @Override
            public void run() {
                if (requestSession != sessionId || !isCurrentUtterance(utteranceId)
                        || !reading || paused) {
                    stallWatchdog = null;
                    return;
                }
                boolean speaking;
                try {
                    speaking = engineManager.isSpeaking();
                } catch (Exception e) {
                    // Si no se puede consultar el estado, se prefiere no actuar.
                    speaking = true;
                }
                if (speaking) {
                    stallMissCount = 0;
                } else {
                    stallMissCount++;
                    if (stallMissCount >= 2) {
                        stallWatchdog = null;
                        cancelUtteranceTimeout();
                        handleUtteranceFinished();
                        return;
                    }
                }
                handler.postDelayed(this, STALL_CHECK_MS);
            }
        };
        handler.postDelayed(stallWatchdog, STALL_CHECK_MS);
    }

    private void cancelStallWatchdog() {
        if (stallWatchdog != null) {
            handler.removeCallbacks(stallWatchdog);
            stallWatchdog = null;
        }
        stallMissCount = 0;
    }

    private void cancelUtteranceTimeout() {
        cancelStallWatchdog();
        if (utteranceTimeout != null) {
            handler.removeCallbacks(utteranceTimeout);
            utteranceTimeout = null;
        }
    }

    private float clampRate(float value) {
        if (value < 0.5f) return 0.5f;
        if (value > 2.0f) return 2.0f;
        return value;
    }

    private float clampPitch(float value) {
        if (value < 0.5f) return 0.5f;
        if (value > 2.0f) return 2.0f;
        return value;
    }

    private String cleanForTts(String value) {
        if (value == null) return "";
        String text = value.replace('\u00A0', ' ');
        text = text.replace("\\r\\n", "\n");
        text = text.replace("\\n", "\n");
        text = text.replace("\\r", "\n");
        text = text.replace("/n", "\n");
        text = text.replace('\r', '\n');
        text = text.replaceAll("(?m)^\\s*[\\\\/]*[NnÑñ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[A-ZÑ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[a-zñ]\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[0-9]{1,4}\\s*$", "");
        text = text.replaceAll("(?m)^\\s*[IVXLCDMivxlcdm]{1,8}\\s*$", "");
        text = text.replaceFirst("(?i)^(\\s*[nñ]\\s+){1,10}", "");
        text = text.replaceAll("(?i)(^|[\\s\\n\\r\\t.,;:!¡?¿()\\[\\]{}\\-])[nñ](?=($|[\\s\\n\\r\\t.,;:!¡?¿()\\[\\]{}\\-]))", "$1");
        text = text.replaceAll("(?iu)([a-záéíóúüñ])-\\s*\\n\\s*([a-záéíóúüñ])", "$1$2");
        text = text.replaceAll("[ \\t]{2,}", " ");
        text = text.replaceAll("\\n[ \\t]+", "\n");
        text = text.replaceAll("\\n{3,}", "\n\n");
        return text.trim();
    }


    private int firstWordEnd(String text) {
        if (text == null || text.length() == 0) return 1;
        int i = 0;
        while (i < text.length() && Character.isWhitespace(text.charAt(i))) i++;
        while (i < text.length() && !Character.isWhitespace(text.charAt(i))) i++;
        return Math.max(1, i);
    }

    private void broadcastReadingRange(int start, int end) {
        try {
            String chunk = (currentChunkIndex >= 0 && currentChunkIndex < currentChunks.size())
                    ? currentChunks.get(currentChunkIndex) : "";
            Intent update = new Intent(ACTION_PAGE_CHANGED);
            update.setPackage(getPackageName());
            update.putExtra(EXTRA_PAGE, currentPageAbsolute);
            update.putExtra(EXTRA_STATE, playbackState);
            update.putExtra(EXTRA_MESSAGE, "Pagina " + (currentPageAbsolute + 1));
            update.putExtra(EXTRA_CHUNK_TEXT, chunk);
            update.putExtra(EXTRA_CHUNK_INDEX, currentChunkIndex);
            update.putExtra(EXTRA_RANGE_START, Math.max(0, start));
            update.putExtra(EXTRA_RANGE_END, Math.max(start + 1, end));
            sendBroadcast(update);
        } catch (Exception ignored) {
        }
    }

    private void savePlaybackState(int page, int state, String message) {
        playbackState = state;
        boolean active = state == STATE_PREPARING || state == STATE_PLAYING
                || state == STATE_PAUSED;
        boolean isPaused = state == STATE_PAUSED;
        try {
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                    .putBoolean(PREF_TTS_ACTIVE, active)
                    .putBoolean(PREF_TTS_PAUSED, isPaused)
                    .putInt(PREF_TTS_CURRENT_PAGE, page)
                    .putInt(PREF_TTS_STATE, state)
                    .putString(PREF_TTS_MESSAGE, message == null ? "" : message)
                    .apply();
            Intent update = new Intent(ACTION_PAGE_CHANGED);
            update.setPackage(getPackageName());
            update.putExtra(EXTRA_PAGE, page);
            update.putExtra(EXTRA_ACTIVE, active);
            update.putExtra(EXTRA_PAUSED, isPaused);
            update.putExtra(EXTRA_STATE, state);
            update.putExtra(EXTRA_MESSAGE, message == null ? "" : message);
            sendBroadcast(update);
        } catch (Exception ignored) {
        }
    }



    private void ensureForeground(String text) {
        startForeground(NOTIFICATION_ID, buildNotification(text));
        foregroundStarted = true;
    }

    private Notification buildNotification(String text) {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        openIntent.putExtra("open_reading_page", true);
        PendingIntent openPi = PendingIntent.getActivity(this, 0, openIntent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent prevPi = PendingIntent.getService(this, 1,
                new Intent(this, TtsForegroundService.class).setAction(ACTION_PREV),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent togglePi = PendingIntent.getService(this, 2,
                new Intent(this, TtsForegroundService.class).setAction(ACTION_TOGGLE),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent nextPi = PendingIntent.getService(this, 3,
                new Intent(this, TtsForegroundService.class).setAction(ACTION_NEXT),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent closePi = PendingIntent.getService(this, 4,
                new Intent(this, TtsForegroundService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        boolean showPlay = playbackState == STATE_PAUSED || playbackState == STATE_STOPPED;
        String safeTitle = title == null || title.trim().length() == 0 || "PDF a Audio".equals(title)
                ? UiStrings.translate(this, "PDF a Audio") : title;
        String pageLabel = UiStrings.translate(this, totalPages > 0
                ? "Página " + (currentPageAbsolute + 1) + "/" + totalPages
                : "Página " + (currentPageAbsolute + 1));
        String status;
        if (playbackState == STATE_PLAYING) {
            status = pageLabel + " · " + UiStrings.translate(this, "Leyendo") + " · "
                    + String.format(Locale.US, "%.2fx", rate);
        } else if (playbackState == STATE_PAUSED) {
            status = pageLabel + " · " + UiStrings.translate(this, "Pausado");
        } else if (playbackState == STATE_PREPARING) {
            status = pageLabel + " · " + UiStrings.translate(this, "Preparando");
        } else {
            status = pageLabel;
        }

        RemoteViews compact = new RemoteViews(getPackageName(), R.layout.notification_pdf_audio);
        int toggleIcon = showPlay ? R.drawable.ic_media_play : R.drawable.ic_media_pause;

        bindNotificationViews(compact, safeTitle, status, toggleIcon, prevPi, togglePi, nextPi, closePi);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setSmallIcon(R.drawable.ic_notification_blank)
                .setContentTitle(safeTitle)
                .setContentText(status)
                .setContentIntent(openPi)
                .setOngoing(playbackState != STATE_STOPPED && playbackState != STATE_ERROR)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setCustomContentView(compact);

        // V102: no BigContentView ni estilo expandible. La notificación conserva
        // el mismo tamaño compacto al desplegar el panel.
        if (Build.VERSION.SDK_INT >= 21) {
            builder.setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setCategory(Notification.CATEGORY_SERVICE)
                    .setColor(0xFF08283A);
        }
        if (Build.VERSION.SDK_INT >= 31) {
            builder.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        if (Build.VERSION.SDK_INT < 26) builder.setPriority(Notification.PRIORITY_LOW);
        return builder.build();
    }

    private void bindNotificationViews(RemoteViews views, String safeTitle, String status,
                                       int toggleIcon, PendingIntent prevPi,
                                       PendingIntent togglePi, PendingIntent nextPi,
                                       PendingIntent closePi) {
        views.setTextViewText(R.id.notification_app_name, UiStrings.translate(this, "PDF a Audio"));
        views.setTextViewText(R.id.notification_title, safeTitle);
        views.setTextViewText(R.id.notification_status, status);
        views.setImageViewResource(R.id.notification_toggle, toggleIcon);
        views.setContentDescription(R.id.notification_prev, UiStrings.translate(this, "Anterior"));
        views.setContentDescription(R.id.notification_toggle, UiStrings.translate(this, "Reproducir o pausar"));
        views.setContentDescription(R.id.notification_next, UiStrings.translate(this, "Siguiente"));
        views.setContentDescription(R.id.notification_close, UiStrings.translate(this, "Cerrar"));
        views.setOnClickPendingIntent(R.id.notification_prev, prevPi);
        views.setOnClickPendingIntent(R.id.notification_toggle, togglePi);
        views.setOnClickPendingIntent(R.id.notification_next, nextPi);
        views.setOnClickPendingIntent(R.id.notification_close, closePi);
    }

    private void updateNotification(String text) {
        if (!foregroundStarted) return;
        NotificationManager manager =
                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildNotification(text));
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    UiStrings.translate(this, "PDF a Audio"), NotificationManager.IMPORTANCE_LOW);
            channel.setDescription(UiStrings.translate(this, "Lectura de PDF en segundo plano"));
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            channel.enableVibration(false);
            channel.setSound(null, null);
            NotificationManager manager =
                    (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void acquirePlaybackResources() {
        acquireAudioFocus();
        if (wakeLock != null && !wakeLock.isHeld()) {
            try { wakeLock.acquire(60 * 60 * 1000L); } catch (Exception ignored) {}
        }
    }

    private void acquireAudioFocus() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                if (audioFocusRequest == null) {
                    AudioAttributes attributes = new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build();
                    audioFocusRequest = new AudioFocusRequest.Builder(
                            AudioManager.AUDIOFOCUS_GAIN)
                            .setAudioAttributes(attributes)
                            .setOnAudioFocusChangeListener(focusChangeListener)
                            .setWillPauseWhenDucked(false)
                            .build();
                }
                audioManager.requestAudioFocus(audioFocusRequest);
            } else {
                audioManager.requestAudioFocus(focusChangeListener,
                        AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
            }
        } catch (Exception ignored) {
        }
    }

    private void releaseAudioFocus() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= 26 && audioFocusRequest != null) {
                audioManager.abandonAudioFocusRequest(audioFocusRequest);
            } else {
                audioManager.abandonAudioFocus(focusChangeListener);
            }
        } catch (Exception ignored) {
        }
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (Exception ignored) {}
        }
    }

    @Override
    public void onDestroy() {
        if (liveInstance == this) liveInstance = null;
        cancelProviderTimeout();
        cancelUtteranceTimeout();
        releaseFastResumePlayer();
        releaseAudioFocus();
        releaseWakeLock();
        if (engineManager != null) {
            engineManager.removeUtteranceListener(utteranceListener);
            engineManager.stop();
        }

        if (playbackState != STATE_STOPPED && playbackState != STATE_ERROR) {
            savePlaybackState(currentPageAbsolute, STATE_STOPPED, "Detenido");
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
