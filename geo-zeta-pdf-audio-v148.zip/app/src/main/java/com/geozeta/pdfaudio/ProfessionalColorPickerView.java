package com.geozeta.pdfaudio;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/** Smooth saturation/value plane for a selected hue. Uses GPU-friendly gradients, never bitmaps. */
public class ProfessionalColorPickerView extends View {
    public interface OnColorChangedListener {
        void onColorChanged(int color);
    }

    private final Paint saturationPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint valuePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint indicatorOuterPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint indicatorInnerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clipPath = new Path();

    private float hue = 0f;
    private float selectedX = 1f; // saturation
    private float selectedY = 0f; // 1 - value
    private int selectedColor = Color.RED;
    private final float[] hsvScratch = new float[]{0f, 1f, 1f};
    private int shaderWidth = -1;
    private int shaderHeight = -1;
    private float shaderHue = -1f;
    private OnColorChangedListener listener;

    public ProfessionalColorPickerView(Context context) {
        this(context, null);
    }

    public ProfessionalColorPickerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setFocusable(true);
        setClickable(true);

        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(dp(1));
        borderPaint.setColor(Color.rgb(148, 163, 184));

        indicatorOuterPaint.setStyle(Paint.Style.STROKE);
        indicatorOuterPaint.setStrokeWidth(dp(3));
        indicatorOuterPaint.setColor(Color.WHITE);

        indicatorInnerPaint.setStyle(Paint.Style.STROKE);
        indicatorInnerPaint.setStrokeWidth(dp(1.2f));
        indicatorInnerPaint.setColor(Color.rgb(15, 23, 42));
    }

    public void setOnColorChangedListener(OnColorChangedListener listener) {
        this.listener = listener;
    }

    public int getSelectedColor() {
        return selectedColor;
    }

    public float getHue() {
        return hue;
    }

    public void setHue(float hueValue) {
        float normalized = normalizeHue(hueValue);
        if (Math.abs(normalized - hue) < 0.05f) return;
        hue = normalized;
        selectedColor = colorAt(selectedX, selectedY);
        shaderHue = -1f;
        invalidate();
        notifyColor();
    }

    public void setColor(int color) {
        float[] hsv = new float[3];
        Color.colorToHSV(0xFF000000 | (color & 0x00FFFFFF), hsv);
        hue = normalizeHue(hsv[0]);
        selectedX = clamp(hsv[1], 0f, 1f);
        selectedY = 1f - clamp(hsv[2], 0f, 1f);
        selectedColor = colorAt(selectedX, selectedY);
        shaderHue = -1f;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        shaderWidth = -1;
        shaderHeight = -1;
        invalidate();
    }

    private void ensureShaders() {
        int w = Math.max(1, getWidth());
        int h = Math.max(1, getHeight());
        if (w == shaderWidth && h == shaderHeight && Math.abs(shaderHue - hue) < 0.05f) return;

        int pureHue = Color.HSVToColor(new float[]{hue, 1f, 1f});
        saturationPaint.setShader(new LinearGradient(
                0f, 0f, w, 0f,
                Color.WHITE, pureHue,
                Shader.TileMode.CLAMP));
        valuePaint.setShader(new LinearGradient(
                0f, 0f, 0f, h,
                Color.TRANSPARENT, Color.BLACK,
                Shader.TileMode.CLAMP));
        shaderWidth = w;
        shaderHeight = h;
        shaderHue = hue;
    }

    private int colorAt(float saturation, float valueAxis) {
        hsvScratch[0] = hue;
        hsvScratch[1] = clamp(saturation, 0f, 1f);
        hsvScratch[2] = 1f - clamp(valueAxis, 0f, 1f);
        return Color.HSVToColor(hsvScratch);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        ensureShaders();

        RectF rect = new RectF(0f, 0f, getWidth(), getHeight());
        float radius = dp(14);
        int save = canvas.save();
        clipPath.reset();
        clipPath.addRoundRect(rect, radius, radius, Path.Direction.CW);
        canvas.clipPath(clipPath);
        canvas.drawRect(rect, saturationPaint);
        canvas.drawRect(rect, valuePaint);
        canvas.restoreToCount(save);

        RectF border = new RectF(dp(0.5f), dp(0.5f), getWidth() - dp(0.5f), getHeight() - dp(0.5f));
        canvas.drawRoundRect(border, radius, radius, borderPaint);

        float cx = selectedX * Math.max(1, getWidth() - 1);
        float cy = selectedY * Math.max(1, getHeight() - 1);
        float indicatorRadius = dp(9);
        canvas.drawCircle(cx, cy, indicatorRadius, indicatorOuterPaint);
        canvas.drawCircle(cx, cy, indicatorRadius - dp(2), indicatorInnerPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE) {
            selectedX = clamp(event.getX() / Math.max(1f, getWidth()), 0f, 1f);
            selectedY = clamp(event.getY() / Math.max(1f, getHeight()), 0f, 1f);
            selectedColor = colorAt(selectedX, selectedY);
            notifyColor();
            postInvalidateOnAnimation();
            return true;
        }
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            performClick();
            return true;
        }
        return super.onTouchEvent(event);
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private void notifyColor() {
        if (listener != null) listener.onColorChanged(selectedColor);
    }

    private float normalizeHue(float value) {
        float result = value % 360f;
        if (result < 0f) result += 360f;
        return result;
    }

    private float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }
}
