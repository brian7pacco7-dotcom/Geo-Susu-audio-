# ============================================================
# Geo Zeta PDF a Audio - Reglas R8 / ProGuard para release
# ============================================================
# IMPORTANTE: sin estas reglas la app compila pero CRASHEA al
# abrir un PDF en la version de release (en debug funciona bien,
# porque debug no ofusca). Todo lo de abajo esta puesto para que
# eso no pase.
# ============================================================


# ------------------------------------------------------------
# PDFBox para Android (com.tom-roush:pdfbox-android)
# ------------------------------------------------------------
# PDFBox carga parsers, fuentes y filtros por nombre (reflexion),
# no por llamada directa. R8 no puede "ver" esos usos, asi que si
# no se le dice que los conserve, los borra por creer que no se
# usan, y la app revienta al abrir el primer PDF.
-keep class com.tom_roush.** { *; }
-dontwarn com.tom_roush.**
-keep class org.apache.pdfbox.** { *; }
-keep class org.apache.fontbox.** { *; }
-dontwarn org.apache.pdfbox.**
-dontwarn org.apache.fontbox.**


# ------------------------------------------------------------
# BouncyCastle (viene dentro de PDFBox, para PDFs encriptados)
# ------------------------------------------------------------
# Causa #1 de crashes en release con PDFBox. BouncyCastle registra
# sus algoritmos con clases internas llamadas "Mappings" que se
# instancian por reflexion. Si se ofuscan, el error tipico es:
#   InternalError: cannot create instance of ...$Mappings
-keep class org.bouncycastle.** { *; }
-dontwarn org.bouncycastle.**
-keep class org.bouncycastle.jcajce.provider.** { *; }
-keep class org.bouncycastle.jcajce.provider.digest.** { *; }
-keep class org.bouncycastle.jcajce.provider.**.Mappings { *; }
-keep class org.bouncycastle.jce.provider.** { *; }


# ------------------------------------------------------------
# Clases de Java de escritorio que no existen en Android
# ------------------------------------------------------------
# BouncyCastle referencia LDAP/JNDI, que en Android no existen.
# Nunca se ejecutan aqui, pero sin estos -dontwarn el build FALLA
# con "can't find referenced class javax.naming.NamingException".
-dontwarn javax.naming.**
-dontwarn javax.naming.directory.**
-dontwarn javax.xml.**
-dontwarn java.awt.**
-dontwarn javax.imageio.**


# ------------------------------------------------------------
# Clases propias declaradas en el AndroidManifest
# ------------------------------------------------------------
# Android las crea por nombre, no con "new". R8 ya suele
# conservarlas, pero se dejan explicitas para que un cambio de
# configuracion futuro no las borre por accidente.
-keep class com.geozeta.pdfaudio.GeoZetaApplication { *; }
-keep class com.geozeta.pdfaudio.MainActivity { *; }
-keep class com.geozeta.pdfaudio.TtsForegroundService { *; }


# ------------------------------------------------------------
# Vistas personalizadas
# ------------------------------------------------------------
# Se conservan los constructores que Android usa para inflar
# vistas desde XML y los setters de animacion.
-keep public class * extends android.view.View {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
    public void set*(...);
}


# ------------------------------------------------------------
# Atributos necesarios en tiempo de ejecucion
# ------------------------------------------------------------
# Signature/InnerClasses hacen falta para genericos y reflexion.
# SourceFile + LineNumberTable permiten que los reportes de fallo
# de Play Console muestren en que linea se rompio (se ofuscan
# igual, pero Play los "des-ofusca" con el mapping.txt).
-keepattributes Signature, InnerClasses, EnclosingMethod
-keepattributes RuntimeVisibleAnnotations, AnnotationDefault
-keepattributes SourceFile, LineNumberTable
-renamesourcefileattribute SourceFile


# ------------------------------------------------------------
# Nota: NO agregar -dontobfuscate, -dontoptimize ni -dontshrink.
# Sirven solo para depurar; en release anulan la proteccion del
# codigo y el ahorro de tamano.
# ------------------------------------------------------------
